"""Reproducible public research fetch. No credentials or private source reuse."""
from pathlib import Path
from urllib.parse import urlencode, quote
import urllib.request, urllib.error
import hashlib, json, datetime, time

ROOT=Path(__file__).resolve().parents[1]
OUT=ROOT/'research/su-sources'
OUT.mkdir(parents=True,exist_ok=True)
MANIFEST={'person':'蘇巧慧','term':11,'start':'2024-02-01','end':'2026-10-20','requests':[]}

def fetch(url,name,maxbytes=80000000):
    path=OUT/name
    for attempt in range(3):
        try:
            req=urllib.request.Request(url,headers={'User-Agent':'PublicParliamentResearch/1.0'})
            with urllib.request.urlopen(req,timeout=90) as response:
                raw=response.read(maxbytes+1)
                if len(raw)>maxbytes:raise ValueError('response too large')
                status=response.status
            data=json.loads(raw.decode('utf-8-sig'))
            if isinstance(data,dict) and data.get('error'):raise ValueError('upstream returned error')
            path.write_bytes(raw)
            MANIFEST['requests'].append({'url':url,'file':str(path.relative_to(ROOT)).replace('\\','/'),
                'retrievedAt':datetime.datetime.now(datetime.timezone.utc).isoformat(),'status':status,'bytes':len(raw),'sha256':hashlib.sha256(raw).hexdigest()})
            (OUT/'fetch-manifest.json').write_text(json.dumps(MANIFEST,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
            print(name,len(raw),'bytes',flush=True)
            return data
        except Exception as error:
            print(name,'attempt',attempt+1,type(error).__name__,flush=True)
            if attempt==2:raise
            time.sleep(20*(attempt+1))

person=quote('蘇巧慧')
base='https://ly.govapi.tw/v2/legislators/11/'+person
fetch(base,'legislator.json')
fields=['議案編號','議案名稱','提案日期','最新進度日期','提案人','連署人','案由','說明','議案流程','議案狀態','議案類別','對照表','資料抓取時間','提案來源','法律編號','相關附件','會議代碼']
params=[('limit','1000')]+[('output_fields',f) for f in fields]
for role in ['propose_bills','cosign_bills']:
    first=fetch(base+'/'+role+'?'+urlencode(params+[('page','1')]),role+'-page-1.json')
    print(role,'total',first.get('total'),'pages',first.get('total_page'),flush=True)
    for page in range(2,int(first['total_page'])+1):
        fetch(base+'/'+role+'?'+urlencode(params+[('page',str(page))]),role+f'-page-{page}.json')
for proposer,name in [('蘇巧慧','official-proposals-su.json'),('','official-proposals-all.json')]:
    params={'from':'1130201','to':'1151020','mode':'json'}
    if proposer:params['proposer']=proposer
    try:fetch('https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx?'+urlencode(params),name)
    except Exception as error:print(name,'unavailable',type(error).__name__,flush=True)
