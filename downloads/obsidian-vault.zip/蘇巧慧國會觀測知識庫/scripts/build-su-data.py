"""Build Su-only evidence data from preserved public source responses.
Role counts use the same disjoint bill-ID definition as the Puwa project.
Primary target/purpose classification is reviewed per bill; others are explicit
rule-based preliminary labels and never silently inherit primary assignments.
"""
from pathlib import Path
from collections import Counter
import json,re,datetime,hashlib,html

ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'research/su-sources';OUT=ROOT/'site/dist/data'
OUT.mkdir(parents=True,exist_ok=True)
START,END,NOM='2024-02-01','2026-10-20','2025-11-26'
PERSON='蘇巧慧'
def load(name):return json.loads((SRC/name).read_text(encoding='utf-8-sig'))
def save(path,obj):path.write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def norm(t):return re.sub(r'[^\u4e00-\u9fffA-Za-z0-9]','',t).replace('請審議案','')
def names(value):return [x.strip() for x in value.split(';') if x.strip()]
def shortname(value):return re.match(r'[\u4e00-\u9fff]+',value).group() if re.match(r'[\u4e00-\u9fff]+',value) else value
def isodate(roc):return f'{int(roc[:3])+1911:04d}-{roc[3:5]}-{roc[5:7]}'
def official_role(b):
 p,c=names(b.get('billProposer','')),names(b.get('billCosignatory',''))
 return 'primary' if p and p[0]==PERSON else 'joint' if PERSON in p else 'cosign' if PERSON in c else None

# id | institutional/regulated target | substantive purpose | common comparison ID
MANUAL='''
202110232390000|保全、警政與消防制度|放寬保全人員年齡上限、保障中高齡工作權|work
202110220480000|勞動、就業與社會保險|育兒留停與所得支持、促進共同照顧|work
202110220490000|勞動、就業與社會保險|育兒留停與工作家庭平衡|work
202110085930000|勞動、就業與社會保險|擴大親職假別與友善生養職場|work
202110217690000|醫療、健康與醫事制度|漢生病隔離歷史的人權補償與名譽回復|justice
202110217680000|文化、圖書與藝術制度|設置樂生醫療人權文化館、保存醫療人權歷史|culture
202110214890000|財稅、產業與科技制度|調整小規模營業人標準及營業稅申報頻率|economy
202110186740000|社會福利與照顧制度|身障合理調整、反騷擾與機構人身安全|care
202110186030000|住宅、土地與都市計畫|將社會住宅明定為公共設施用地|economy
202110186040000|文化、圖書與藝術制度|出版品送存給付與公共借閱補償|culture
202110186050000|國會、地方治理與公投|公費助理心理諮商與職場身心健康支持|work
202110186430000|保全、警政與消防制度|釐清警政署業務與警察職權規定|governance
202110186440000|財稅、產業與科技制度|設置太空發展基金、支持太空產業|economy
202110186450000|文化、圖書與藝術制度|國防機敏工程的公共藝術經費例外|security
202110134270000|社會福利與照顧制度|未滿二歲兒童托育品質與機構管理|care
202110113640000|住宅、土地與都市計畫|公益出租人的租稅誘因及租屋供給|economy
202110072040000|住宅、土地與都市計畫|未成年身障者家庭的社宅申請資格|care
202110140000000|司法與犯罪防制制度|詐欺減刑條件與被害財產返還|justice
202110164380000|交通、船舶與通行制度|外國船舶航行管理與海纜安全|security
202110166850000|環境、海洋與災害制度|災民及親屬協助家園復原重建|environment
202110113650000|財稅、產業與科技制度|設置海洋科技營運中心、強化研究量能|economy
202110113630000|保全、警政與消防制度|大型群聚活動安全管理與事故預防|governance
202110113670000|醫療、健康與醫事制度|打擊牟利代掛號、保障醫療資源平等使用|health
202110113660000|勞動、就業與社會保險|育有幼兒之國民年金被保險人保費支持|work
202110085910000|環境、海洋與災害制度|完善動物福利及動物保護制度|environment
202110085920000|財稅、產業與科技制度|檢討娛樂稅課徵範圍與適用活動|economy
202110072310000|保全、警政與消防制度|消防人員職業安全衛生保障|work
202110067670000|醫療、健康與醫事制度|癌症防治策略、照護與防治基金|health
202110055000000|司法與犯罪防制制度|防詐、打擊詐欺與犯罪被害人保護|justice
202110036450000|醫療、健康與醫事制度|癌症防治策略與防治基金（後撤案）|health
202110017340000|環境、海洋與災害制度|海洋保育、復育與生物多樣性|environment
202110037370000|國籍、移民與族群制度|新住民基本權益與多元文化平等|governance
202110042180000|國會、地方治理與公投|地方議員助理與村里事務補助待遇|work
202110017780000|國籍、移民與族群制度|非本國籍無依兒少及歸化者子女權益|care
202110027890000|交通、船舶與通行制度|行人安全設施與以人為本用路環境|mobility
202110017790000|國會、地方治理與公投|全國性公投的不在籍投票制度|governance
202110017800000|國籍、移民與族群制度|原住民族工作機會、進用與採購保障|work
202110017810000|教育與校園制度|教師專業倫理與校園性別事件處理|education
202110017820000|教育與校園制度|不適任教育人員與校園安全規範|education
'''
manual={row.split('|')[0]:row.split('|')[1:] for row in MANUAL.strip().splitlines()}
TOPICS={'security':'國安、兩岸與防衛','justice':'司法、法治與人權','care':'兒少權益與照顧服務','education':'教育與人才','digital':'數位、AI與個資','work':'勞動、育兒職場與社保','mobility':'交通、港航與通行','environment':'環境、能源、基設與防災','culture':'文化、運動與休閒','economy':'經濟、財稅、產業與住宅','health':'醫療、食安與健康','governance':'政治制度、治理與交流'}
RULES=[(r'陸海空軍|國防|軍事|軍人|志願士兵','國防與軍職制度','security'),(r'教育|教師|學校|大學|校園','教育與校園制度','education'),(r'圖書|文化|藝術|出版|運動|體育','文化、圖書與藝術制度','culture'),(r'勞動|勞工|就業|性別平等工作|年金|退休|職業安全','勞動、就業與社會保險','work'),(r'醫療|醫師|癌症|健康|食品|食安|藥|菸害','醫療、健康與醫事制度','health'),(r'兒童|少年|托育|身心障礙|老人|社會救助|長期照顧','社會福利與照顧制度','care'),(r'住宅|土地|都市計畫|都市更新','住宅、土地與都市計畫','economy'),(r'警察|消防|保全|大型群聚','保全、警政與消防制度','governance'),(r'刑|詐欺|法院|訴訟|律師|監獄|毒品|犯罪','司法與犯罪防制制度','justice'),(r'資通|個人資料|人工智慧|數位|電子簽章','資通、AI與個資制度','digital'),(r'交通|道路|公路|船舶|商港|鐵路|汽車','交通、船舶與通行制度','mobility'),(r'環境|海洋|災害|颱風|重建|水|氣候|電業|能源|動物','環境、海洋與災害制度','environment'),(r'國籍|入出國|移民|原住民|新住民','國籍、移民與族群制度','governance'),(r'兩岸|大陸地區|香港澳門|國家安全|反滲透|國家機密','兩岸、國安與交流制度','security'),(r'稅|金融|保險|產業|公司|證券|經濟|太空|科技','財稅、產業與科技制度','economy'),(r'立法院|立法委員|公投|選舉|公務|地方制度|組織|監察|總統|政黨|民意代表','國會、地方治理與公投','governance')]
def classify_rule(title):
 for pattern,target,topic in RULES:
  if re.search(pattern,title):return target,'依法律名稱初步規則標記（未逐案人工複核）',topic
 return '其他／待分類','尚待人工分類',None

raw=[]
for role in ['propose_bills','cosign_bills']:
 first=load(role+'-page-1.json');rows=[]
 for page in range(1,first['total_page']+1):rows.extend(load(role+f'-page-{page}.json')['bills'])
 assert len(rows)==first['total'];raw.extend(rows)
# A full official-API crosscheck found a mirror omission: its parsed cosigner
# array had only 7 of the 15 names visible on the official relationship PDF.
extra=load('bill-202110079830000.json')['data']
extra['連署人']=['王美惠','陳素月','陳秀寳','吳琪銘','何欣純','蘇巧慧','黃捷','劉建國','林月琴','陳冠廷','范雲','林楚茵','沈伯洋','羅美玲','李柏毅']
raw.append(extra)
unique={b['議案編號']:b for b in raw};excluded=[];bills=[]
pdf_audit={x['id']:x for x in load('official-pdf-role-audit.json')}
committee_names=['內政委員會','外交及國防委員會','經濟委員會','財政委員會','教育及文化委員會','交通委員會','司法及法制委員會','社會福利及衛生環境委員會']
official=load('official-proposals-su.json');off_all=load('official-proposals-all.json')
official_by_key={}
for row in off_all:
 official_by_key.setdefault((isodate(row['date']),norm(row['billName'])),[]).append(row)
cross=[]
for ident,b in unique.items():
 if b['議案類別']!='法律案' or not START<=b['提案日期']<=END:
  excluded.append({'id':ident,'date':b['提案日期'],'type':b['議案類別'],'reason':'不在截止日期內' if b['議案類別']=='法律案' else '非法律案'});continue
 ps,cs=b.get('提案人',[]),b.get('連署人',[])
 role='primary' if ps and ps[0]==PERSON else 'joint' if PERSON in ps else 'cosign' if PERSON in cs else None
 assert role,ident
 steps=b.get('議案流程',[])
 committees=[c for c in committee_names if any(c.replace('委員會','') in (s.get('院會/委員會','')+' '+s.get('狀態','')) for s in steps)] or ['流程未載委員會名稱']
 target,purpose,topic=manual[ident] if role=='primary' else classify_rule(b.get('議案名稱',''))
 amendment='\n\n'.join('\n'.join(str(row.get(k,'')) for k in ['修正','增訂','說明'] if row.get(k)) for table in b.get('對照表',[]) for row in table.get('rows',[]))
 matches=official_by_key.get((b['提案日期'],norm(b['議案名稱'])),[])
 candidates=[r for r in matches if names(r['billProposer']) and shortname(names(r['billProposer'])[0])==shortname(ps[0])]
 confirmed=any(official_role(r)==role for r in candidates)
 record={'id':ident,'title':b['議案名稱'],'date':b['提案日期'],'role':role,'url':b.get('url') or f'https://ppg.ly.gov.tw/ppg/bills/{ident}/details',
  'proposers':ps,'cosigners':cs,'committees':committees,'targetTopic':target,'purposeTopic':purpose,'manualTopic':purpose if role=='primary' else None,
  'mainTopic':topic,'comparisonTopic':topic,'topics':[TOPICS[topic]] if topic else ['其他／待分類'],'status':b.get('議案狀態','未載'),
  'flow':steps,'steps':steps,'reason':b.get('案由',''),'text':amendment,'explanation':b.get('說明',''),
  'sourceUrls':[b.get('url') or f'https://ppg.ly.gov.tw/ppg/bills/{ident}/details']+[x['網址'] for x in b.get('相關附件',[]) if x.get('網址','').startswith('https://ppg.ly.gov.tw/')],
  'sourceAttachments':b.get('相關附件',[]),'upstreamFetched':b.get('資料抓取時間'),'latestProgress':b.get('最新進度日期'),
  'classificationMethod':'逐案人工依案由／修正條文確認；標的與目的分軸' if role=='primary' else '依法律名稱可重現規則初標；未人工逐案複核',
  'officialRoleCrosscheck':{'sameDateAndTitleAndLead':confirmed,'source':'https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx?from=1130201&to=1151020&mode=json','officialDocument':pdf_audit.get(ident),'confirmed':confirmed or ident in pdf_audit},
  'nominationPhase':'before' if b['提案日期']<NOM else 'after',
  'returns':sum('退回程序委員會' in s.get('狀態','') for s in steps),
  'returnSteps':[s for s in steps if '退回程序委員會' in s.get('狀態','')]}
 bills.append(record)
 cross.append({'id':ident,'role':role,'date':b['提案日期'],'title':b['議案名稱'],'officialMatched':confirmed,'officialDocument':pdf_audit.get(ident),'confirmed':confirmed or ident in pdf_audit,'officialCandidateCount':len(candidates)})
bills.sort(key=lambda b:(b['date'],b['id']),reverse=True)
counts=Counter(b['role'] for b in bills)
assert counts=={'primary':39,'joint':30,'cosign':571}
assert all(x['confirmed'] for x in cross)
assert set(manual)=={b['id'] for b in bills if b['role']=='primary'}
official_counts=Counter(official_role(b) for b in official)
assert official_counts=={'primary':39,'joint':30}
def aggregate(field):
 result=[]
 labels=sorted({x for b in bills for x in (b[field] if isinstance(b[field],list) else [b[field]]) if x})
 for label in labels:
  rows=[b for b in bills if label in (b[field] if isinstance(b[field],list) else [b[field]])]
  result.append({'name':label,'count':len(rows),**{r:sum(b['role']==r for b in rows) for r in ['primary','joint','cosign']}})
 return sorted(result,key=lambda x:-x['count'])
primary=[b for b in bills if b['role']=='primary'];proposed=[b for b in bills if b['role']!='cosign']
borderline={'202110217690000':['justice','health'],'202110186050000':['work','health'],'202110186450000':['security','culture'],
 '202110072040000':['care','economy'],'202110164380000':['security','mobility'],'202110166850000':['environment','work'],'202110113650000':['economy','environment']}
analysis={'meta':{'person':PERSON,'term':11,'start':START,'end':END,'elapsedDays':(datetime.date.fromisoformat(END)-datetime.date.fromisoformat(START)).days,
 'retrievedAt':load('fetch-manifest.json')['requests'][0]['retrievedAt'],'nominationDate':NOM,'nominationSource':'https://www.dpp.org.tw/content_print/media/11384',
 'coverageNote':'第11屆法律案限定，以議案編號去重、首位提案／共同提案／連署互斥。主提39與共提30已與立法院本人提案API69筆交叉核對；連署571中，570出自LYAPI本人清單，另依官方全院API與議案原件補回1件漏列（202110079830000）。全640案以官方API逐案對照，7案另核PDF原件；不保證上游零遺漏。排除2件日期2026-10-23的未來資料。流程及最新狀態可能晚於截止日，屬擷取時現況，不是2026-10-20當日歷史快照。',
 'unit':'法律案之唯一議案編號；不是法條數、不是已三讀法律數，也不證明由哪個辦公室撰稿。',
 'excluded':excluded,'officialCrossCheck':{'primary':39,'joint':30,'total':69,'source':'https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx?from=1130201&to=1151020&proposer=%E8%98%87%E5%B7%A7%E6%85%A7&mode=json'}},
 'totals':{**dict(counts),'unique':len(bills),'propose':len(proposed)},'bills':bills,'committees':aggregate('committees'),
 'topics':aggregate('topics'),'targets':aggregate('targetTopic'),'purposes':aggregate('purposeTopic'),
 'primaryTopics':[{'name':TOPICS[t],'id':t,'count':sum(b['mainTopic']==t for b in primary),'ids':[b['id'] for b in primary if b['mainTopic']==t]} for t in TOPICS],
 'committeeMethod':'只擷取議案流程明載的委員會與交付名稱，可多重歸屬；不是委員本人出席或發言次數。',
 'topicMethod':'主提39案逐案人工分類；標的是受規範制度，目的則依案由／修法內容另列。其餘601案為法律名稱規則初標，不宜稱已完成人工語意分析。主題不能用來直接推斷個人意識形態或動機。',
 'classificationAlternatives':[{'id':k,'mainTopic':next(b['mainTopic'] for b in primary if b['id']==k),'plausibleTopics':v,'note':'主分類依明確法案目的決定，替代類別公開供敏感度分析，不為提高相異分數選類。'} for k,v in borderline.items()],
 'statuses':[{'name':k,'count':v} for k,v in Counter(b['status'] for b in proposed).most_common()],
 'procedure':{'count':len(proposed),'primaryCount':len(primary),'returnedBills':sum(bool(b['returns']) for b in proposed),'returnEvents':sum(b['returns'] for b in proposed),
 'currentReturnedBills':sum(b['status']=='退回程序委員會' for b in proposed),'unreferred':sum(b['committees']==['流程未載委員會名稱'] for b in proposed),
 'returnMeetingEvents':sum(len({(s.get('會議代碼') or s.get('會期'),str(s.get('日期',[]))) for s in b['returnSteps']}) for b in proposed),
 'bills':[{'id':b['id'],'title':b['title'],'role':b['role'],'url':b['url'],'returns':b['returns'],'steps':b['returnSteps']} for b in proposed if b['returns']],
 'notes':'退回計流程列數，不能等同實際表決阻擋次數；退回程序不等於撤案或否決。'},
 'nomination':{'date':NOM,'source':'https://www.dpp.org.tw/content_print/media/11384',
 'counts':{phase:{r:sum(b['role']==r and b['nominationPhase']==phase for b in bills) for r in ['primary','joint','cosign']} for phase in ['before','after']},
 'primaryDistribution':{phase:{t:sum(b['mainTopic']==t and b['nominationPhase']==phase for b in primary) for t in TOPICS} for phase in ['before','after']}},
 'sourceMethods':{'structuredMirror':'https://ly.govapi.tw/v2/legislators/11/%E8%98%87%E5%B7%A7%E6%85%A7','officialBillAPI':'https://www.ly.gov.tw/Pages/List.aspx?nodeid=153',
 'person':'https://www.ly.gov.tw/Pages/List.aspx?nodeid=46860','provenance':'research/su-sources/fetch-manifest.json'}}
save(OUT/'analysis.json',analysis);save(OUT/'bills.json',bills)
save(ROOT/'research/su-classification-primary.json',{'method':analysis['topicMethod'],'categories':TOPICS,'assignments':[{'id':b['id'],'title':b['title'],'targetTopic':b['targetTopic'],'purposeTopic':b['purposeTopic'],'mainTopic':b['mainTopic'],'reason':b['reason'],'sourceUrls':b['sourceUrls']} for b in primary],'alternatives':analysis['classificationAlternatives']})
save(ROOT/'research/su-role-crosscheck.json',{'officialProposeCounts':dict(official_counts),'listCounts':dict(counts),'matchedByRole':{r:sum(x['role']==r and x['officialMatched'] for x in cross) for r in counts},
 'unmatched':[x for x in cross if not x['confirmed']], 'pdfVerifiedCount':len(pdf_audit),
 'mirrorOmission':{'id':'202110079830000','mirrorNames':7,'officialPdfCosigners':15,'finding':'本人連署端點漏列；全院官方API發現後，以PDF第1頁及官方議案日期紀錄補回。'},
 'officialCosignCaution':'全院官方API含機關／黨團提案的連署欄帶人名等異常，不直接以該欄總和當作蘇委員連署數。姓名、提案日期和共同提案名單亦存在少數差異，逐案原件優先。','allRecords':cross})
save(ROOT/'research/su-analysis-summary.json',{k:v for k,v in analysis.items() if k!='bills'})
print(json.dumps({'totals':analysis['totals'],'nomination':analysis['nomination']['counts'],'primaryTopics':analysis['primaryTopics'],'procedure':analysis['procedure'],'officialMatched':{r:sum(x['role']==r and x['officialMatched'] for x in cross) for r in counts}},ensure_ascii=False))
