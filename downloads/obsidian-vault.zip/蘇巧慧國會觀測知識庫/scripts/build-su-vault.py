"""Build a standalone Su Obsidian vault from public, preserved data only.

No network requests. No previous-person knowledge base is read. ZIP ordering,
timestamps, permissions and content are deterministic for identical inputs.
"""
from pathlib import Path
from collections import Counter, defaultdict
from datetime import date
from hashlib import sha256
import csv
import io
import json
import re
import zipfile

ROOT = Path(__file__).resolve().parents[1]
DIST = ROOT / 'site' / 'dist' if (ROOT / 'site' / 'dist' / 'data').is_dir() else ROOT
DATA = DIST / 'data'
VAULT = ROOT / 'vault'
DOWNLOADS = DIST / 'downloads'
ROLES = {'primary': '主提案', 'joint': '共同提案', 'cosign': '連署'}
PLACEHOLDER = '流程未載委員會名稱'
FIXED_TIME = (2026, 10, 20, 0, 0, 0)
entries = {}
notes = {}


def read_json(path):
    return json.loads(path.read_text(encoding='utf-8-sig'))


def encoded(value):
    return (json.dumps(value, ensure_ascii=False, indent=2) + '\n').encode('utf-8')


def slug(value):
    return re.sub(r'[\\/:*?"<>|\[\]#^\r\n]', '－', str(value)).strip(' .')[:90]


def wiki(title, label=None):
    return '[[' + title + ('|' + str(label).replace('|', '｜').replace(']', '）') if label else '') + ']]'


def external(url, label='官方來源'):
    return '[' + label + '](' + str(url).replace(' ', '%20').replace(')', '%29') + ')'


def put(path, content):
    value = content.encode('utf-8') if isinstance(content, str) else content
    entries[str(path)] = value


def note(folder, title, body, fields=None):
    if title in notes:
        raise ValueError('Duplicate note title: ' + title)
    prefix = '---\n' + ''.join(str(k) + ': ' + json.dumps(v, ensure_ascii=False) + '\n' for k, v in (fields or {}).items()) + '---\n\n'
    content = prefix + '# ' + title + '\n\n' + body.strip() + '\n'
    path = folder + '/' + title + '.md' if folder else title + '.md'
    put(path, content)
    notes[title] = content


def bill_link(bill):
    return wiki('法案-' + bill['id'], bill['title'])


analysis = read_json(DATA / 'analysis.json')
bills = read_json(DATA / 'bills.json')
quotes_data = read_json(DATA / 'quotes.json')
quotes = quotes_data['quotes']
meta, totals = analysis['meta'], analysis['totals']
assert meta['person'] == '蘇巧慧' and meta['term'] == 11
assert bills == analysis['bills']
counts = Counter(b['role'] for b in bills)
assert len({b['id'] for b in bills}) == len(bills) == totals['unique']
assert all(counts[k] == totals[k] for k in ROLES)
assert sum(counts.values()) == totals['unique']
assert (date.fromisoformat(meta['end']) - date.fromisoformat(meta['start'])).days == meta['elapsedDays']
assert all(meta['start'] <= b['date'] <= meta['end'] for b in bills)
for bill in bills:
    proposers, cosigners = bill.get('proposers', []), bill.get('cosigners', [])
    expected_role = ('primary' if proposers and proposers[0] == '蘇巧慧' else
                     'joint' if '蘇巧慧' in proposers else
                     'cosign' if '蘇巧慧' in cosigners else None)
    assert expected_role == bill['role'], 'Role does not match preserved names: ' + bill['id']
quote_checks = []
for quote in quotes:
    source_text = (ROOT / quote['sourceFile']).read_text(encoding='utf-8-sig')
    needle = re.sub(r'\s+', '', quote['quote'])
    flat = re.sub(r'\s+', '', source_text)
    assert needle in flat and quote['speaker'] == '蘇巧慧', quote['id']
    source_lines = source_text.splitlines()
    location = '\n'.join(source_lines[quote['sourceLineStart'] - 1:quote['sourceLineEnd']])
    assert needle in re.sub(r'\s+', '', location), 'Quote locator mismatch: ' + quote['id']
    quote_checks.append({'id': quote['id'], 'quoteFound': True, 'savedLineLocatorVerified': True})

codebook_path, policy_path = DATA / 'comparison-codebook.json', DATA / 'policy.json'
codebook = read_json(codebook_path) if codebook_path.exists() else {}
policy_data = read_json(policy_path) if policy_path.exists() else {}
policies = policy_data.get('policies', policy_data.get('bundles', policy_data.get('items', [])))
assert isinstance(policies, list)
category_names = {x['id']: x.get('name', x['id']) for x in codebook.get('categories', [])}
for item in analysis.get('primaryTopics', []):
    category_names.setdefault(item['id'], item['name'])
category_names.setdefault('unclassified', '待核對分類')

# Public snapshots are preserved byte-for-byte. Raw campaign HTML and person
# profile responses (which can contain office contact fields) are never copied.
for path in sorted(DATA.glob('*.json')):
    put('data/' + path.name, path.read_bytes())
source_names = ['propose_bills-page-1.json', 'cosign_bills-page-1.json', 'official-proposals-su.json',
                'official-proposals-all.json', 'official-extra-crosscheck-query.json',
                'official-pdf-role-audit.json', 'official-pdf-audit-targets.json', 'ivod-directory-sample.json']
manifest = read_json(ROOT / 'research' / 'su-sources' / 'fetch-manifest.json')
requests = manifest['requests']
public_provenance = {
    'person': meta['person'], 'term': meta['term'], 'start': meta['start'], 'end': meta['end'],
    'requests': [{k: r[k] for k in ['url', 'retrievedAt', 'status', 'bytes', 'sha256'] if k in r} |
                 {'archiveFile': 'research/su-sources/' + Path(r['file']).name if Path(r['file']).name in source_names else None,
                  'originalResponseIncluded': Path(r['file']).name in source_names}
                 for r in requests],
    'omitted': '不收錄人物聯絡資料、原始HTML、私人投稿、審稿資料及部署資訊。官方PDF與目錄HTML保留公共URL及驗證說明，官方PDF的純文字存檔隨包附上。'
}
put('research/su-sources/provenance.json', encoded(public_provenance))
put('research/su-sources/fetch-manifest.json', (ROOT / 'research/su-sources/fetch-manifest.json').read_bytes())
for filename in source_names:
    path = ROOT / 'research' / 'su-sources' / filename
    if path.exists():
        put('research/su-sources/' + filename, path.read_bytes())
for filename in ['su-classification-primary.json', 'su-role-crosscheck.json', 'su-quote-verification.json']:
    put('research/' + filename, (ROOT / 'research' / filename).read_bytes())
for path in sorted((ROOT / 'research/su-sources').glob('bill-*.txt')):
    put('research/su-sources/' + path.name, path.read_bytes())
for filename in ['build-su-data.py', 'build-su-quotes.py', 'fetch-su-records.py']:
    put('scripts/' + filename, (ROOT / 'scripts' / filename).read_bytes())
put('scripts/build-su-vault.py', Path(__file__).read_bytes())

home = '00 蘇巧慧國會觀測知識庫'
note('', home, f'''
這是蘇巧慧第11屆法律案與本人公開發言的獨立資料包。觀測範圍 **{meta['start']} 至 {meta['end']}**；資料擷取於 {meta['retrievedAt']}。資料截點與擷取時間分開記錄。

**{totals['primary']} 件主提案＋{totals['joint']} 件共同提案＋{totals['cosign']} 件連署＝{totals['unique']} 件去重參與法律案。** 三個角色互斥；主提與共同提案合計 {totals['propose']} 件，不再與各角色重複相加。

- {wiki('01 資料範圍與角色定義')}
- {wiki('02 分類方法與不確定性')}
- {wiki('03 比較公式與職權差異')}
- {wiki('04 來源與驗證方法')}
- {wiki('05 重現與資料包說明')}
- {wiki('索引-全部法案')}、{wiki('索引-本人原話')}、{wiki('索引-官網政策')}
- {wiki('索引-委員會')}、{wiki('索引-制度標的')}、{wiki('索引-共同分類')}

{meta['coverageNote']}

本資料包未引用舊人物知識庫的事實或分數。短引文選集不是全部言論的隨機抽樣，文本分類不能單獨證明人格、誠信或隱藏動機。
''', {'type': 'index', 'person': '蘇巧慧', 'term': 11, 'as_of': meta['end']})

note('方法', '01 資料範圍與角色定義', f'''
返回 {wiki(home)}。

{meta['unit']}

主提案是本案提案人名單首位為蘇巧慧；共同提案是名單有她但非首位；連署是她列於連署名單，且不屬前兩者。這是**列名角色**，不能證明哪個辦公室獨力撰稿。

只計第11屆法律案，以議案編號去重。不計預算、決議、質詢，也不把不同案號的相近修法自動合併。排除截止日後的 {len(meta.get('excluded', []))} 件資料，詳見 data/analysis.json 的 meta.excluded。

{meta['coverageNote']}

流程與最新狀態是擷取時取得的現況；不能當作截止日當天的完整歷史快照。官方API的提案69件與主提／共提總數一致；連署逐案交叉核對存在差異，保留原件優先及上游缺漏限制。
''')
note('方法', '02 分類方法與不確定性', f'''
返回 {wiki(home)}。

{analysis['topicMethod']}

1. **制度標的 targetTopic**：被修法律或受規範制度。軍職制度仍屬國防，育兒條文不自動變成兒少保護。
2. **修法目的 purposeTopic**：案由與修正條文想處理的具體問題。與制度標的分開記錄。
3. **流程委員會 committees**：{analysis['committeeMethod']}
4. **共同比較 mainTopic**：每份文件一個共同主題；用於兩側等權分布比較，不與制度標的混為同一個分類軸。

主提案逐案人工編碼；其餘案件的法律名稱規則初標保持明示。data/analysis.json 的 classificationAlternatives 與 research/su-classification-primary.json 保留可爭議案例及替代類別，不為提高差異分數挑選分類。
''')
note('方法', '03 比較公式與職權差異', f'''
返回 {wiki(home)}。

同步率＝Σ min（左側各主題件數／左側總件數，右側各主題件數／右側總件數）×100。

每件法律案與每個政策套案頁各自等權；不按篇幅、預算或重要性加權。100表示此分類下分布相同，0表示沒有共同主題權重。一側沒有文件時不計分，未知主題不得假裝已分類。

正式提名切點為 **{meta['nominationDate']}**，提名當日歸後段。{external(meta['nominationSource'], '提名原始公告')}。

立委修全國法律與市長提出市政方案的職權、文件粒度不同；前後樣本數也不同。同步率是文本主題分布重疊，不是人格或動機分數。政策頁中的多個子主張不可與法律案條文數直接混加。

目前政策資料狀態：{'已收錄 ' + str(len(policies)) + ' 個政策套案頁。' if policies else '尚未匯入經編碼的政策頁；暫不產生政策比較分數，待資料完成重跑建置。'}
''')
note('方法', '04 來源與驗證方法', f'''
返回 {wiki(home)}。

- {wiki('來源-立法院議案API')}：官方本人提案清單與逐案原始附件優先。
- {wiki('來源-LYAPI結構化清單')}：保存提案與連署清單，保留抓取時間、URL與SHA256。
- {wiki('來源-官方iVOD全文')}：短引文以全文、說話者與目錄日期交叉核對；未另核聽原聲或句內秒數。
- {wiki('來源-候選人政策頁')}：只收編碼後的公共政策資料及原始URL，不含競選HTML與聯絡欄位。

資料收錄不等於上游零遺漏。未取得質詢全文不算成零，議案流程沒有出席紀錄也不能推斷未出席。隨包的研究資料保留 research/ 相對路徑，逐字稿 sourceFile 與角色驗證 textFile 可直接找到；sourceHtmlFile、localDateEvidence 以及PDF／圖片路徑描述原始研究證據，未隨包的項目須回官方URL核對。實際附檔以 research/su-sources/provenance.json 與 checksums.json 為準。
''')
note('方法', '05 重現與資料包說明', f'''
返回 {wiki(home)}。

解壓縮後，以 Obsidian「開啟資料夾作為知識庫」選擇本資料夾，從 {wiki(home)} 開始。所有雙向Wiki連結在打包時逐一檢查；不需要帳號、登入或私人金鑰。

data/ 保留網站JSON快照。research/ 保存公開提案與連署原回應、本人及全院提案API、分類與逐案交叉核對、官方逐字稿及PDF文字；沒有私人投稿、原始HTML、部署回條或舊人物知識庫。research/su-sources/provenance.json 明列哪些原回應沒有隨包附上。

scripts/ 保存資料建置與抓取方法。網站聚合數字可由 data/bills.json 重算；原始提案建置所需的API回應保留於原相對目錄。原話腳本另需官方目錄HTML，可回原始URL取回；日期與時鐘的編譯證據保留於 ivod-directory-sample.json。政策頁資料及共同比較分類由各自JSON保留。上游更新後結果可能不同，請優先保留此快照。

checksums.json 對除自身以外每個包內檔案記SHA256。ZIP依檔名排序、固定時間與權限打包，同樣輸入可重現完全相同的檔案雜湊；ZIP本身的最終雜湊記在專案外部驗證報告，避免自指問題。
''')

source_notes = {
    '來源-立法院議案API': f"{external(meta['officialCrossCheck']['source'], '立法院本人提案API')}。主提39、共提30與保存清單一致。research/su-role-crosscheck.json 保存逐案差異，原始議案附件優先。",
    '來源-LYAPI結構化清單': f"{external(analysis['sourceMethods']['structuredMirror'], 'LYAPI人物端點')}。提案／連署原回應附於 research/su-sources/；抓取URL、時間、狀態、bytes、SHA256見 research/su-sources/provenance.json。此服務是結構化鏡像，不能取代官方原件。",
    '來源-官方iVOD全文': '收錄9個官方完整發言片段的精選短引文，跨2024–2026年。原句與蘇委員巧慧發言段核對，日期以官方目錄確認。隨包保存純文字全文及其SHA256；官方影片與目錄保留外部連結。沒有核實句內秒數，也不假稱已核聽原聲。',
    '來源-候選人政策頁': external('https://chiao.tw/policies', '候選人官網政策索引') + '。原始HTML與聯絡資訊不隨包附上；各頁以公開編碼、摘要、擷取與來源資訊為準。'
}
for title, text in source_notes.items():
    note('來源', title, f'返回 {wiki(home)}、{wiki("04 來源與驗證方法")}。\n\n{text}')

bill_by_role = defaultdict(list)
bill_by_committee = defaultdict(list)
bill_by_target = defaultdict(list)
bill_by_category = defaultdict(list)
for b in bills:
    bill_by_role[b['role']].append(b)
    committees = b.get('committees') or [PLACEHOLDER]
    for committee in set(committees):
        bill_by_committee[committee].append(b)
    target = b.get('targetTopic') or '待核對分類'
    category = b.get('mainTopic') or b.get('comparisonTopic') or 'unclassified'
    bill_by_target[target].append(b)
    bill_by_category[category].append(b)
    body = f'返回 {wiki(home)}、{wiki("索引-全部法案")}；{wiki("角色-" + ROLES[b["role"]])}。\n\n'
    body += f"**{b['title']}**\n\n提案日期：{b['date']}；角色：{ROLES[b['role']]}；取得進度：{b.get('status', '未載')}。\n\n"
    body += '制度標的：' + wiki('制度-' + slug(target), target) + '。\n\n'
    body += '修法目的：' + (b.get('purposeTopic') or '待核對') + '。\n\n'
    body += '共同比較：' + wiki('共同分類-' + category, category_names.get(category, category)) + '。\n\n'
    body += '委員會：' + '、'.join(wiki('委員會-' + slug(c), c) for c in committees) + '。\n\n'
    body += '分類方法：' + b.get('classificationMethod', '待核對') + '。詳見' + wiki('02 分類方法與不確定性') + '。\n\n'
    body += '提案人：' + '、'.join(b.get('proposers', [])) + '\n\n連署人：' + '、'.join(b.get('cosigners', [])) + '\n\n'
    body += '## 案由與修正內容\n\n' + str(b.get('reason') or '案由未載') + '\n\n' + str(b.get('text') or '修正對照文字未載') + '\n\n'
    body += '## 已收錄流程\n\n'
    for event in b.get('flow', []):
        body += '- ' + json.dumps(event, ensure_ascii=False) + '\n'
    body += '\n退回流程列數：' + str(b.get('returns', 0)) + '；流程列不是實際表決阻擋次數。\n\n'
    body += '\n'.join('- ' + external(url, '原始議案／附件') for url in dict.fromkeys([b['url']] + b.get('sourceUrls', [])))
    note('法案', '法案-' + b['id'], body, {'type': 'bill', 'bill_id': b['id'], 'date': b['date'], 'role': b['role'], 'main_topic': category})

note('索引', '索引-全部法案', '返回 ' + wiki(home) + '。\n\n' + '\n'.join('- ' + wiki('角色-' + label) + '：' + str(counts[role]) + ' 件' for role, label in ROLES.items()))
for role, rows in bill_by_role.items():
    note('角色', '角色-' + ROLES[role], '返回 ' + wiki('索引-全部法案') + '。\n\n共 ' + str(len(rows)) + ' 件。\n\n' + '\n'.join('- ' + b['date'] + ' ' + bill_link(b) for b in rows))
for title, groups, prefix in [('索引-委員會', bill_by_committee, '委員會-'), ('索引-制度標的', bill_by_target, '制度-'), ('索引-共同分類', bill_by_category, '共同分類-')]:
    note('索引', title, '返回 ' + wiki(home) + '。\n\n' + '\n'.join('- ' + wiki(prefix + (key if prefix == '共同分類-' else slug(key)), category_names.get(key, key)) + '：' + str(len(rows)) + ' 件' for key, rows in sorted(groups.items())))
    for key, rows in groups.items():
        text = '返回 ' + wiki(title) + '、' + wiki('02 分類方法與不確定性') + '。\n\n'
        text += ('此處是流程明載委員會，允許多重歸屬；不是出席或發言次數。\n\n' if prefix == '委員會-' else '')
        text += '\n'.join('- ' + ROLES[b['role']] + ' · ' + bill_link(b) for b in rows)
        note('分類', prefix + (key if prefix == '共同分類-' else slug(key)), text)

quote_links = []
for q in quotes:
    title = '原話-' + q['id']
    quote_links.append('- ' + q['date'] + ' ' + wiki(title, q['title']))
    source = ROOT / q['sourceFile']
    source_bytes = source.read_bytes()
    put(q['sourceFile'], source_bytes)
    body = f"返回 {wiki(home)}、{wiki('索引-本人原話')}、{wiki('來源-官方iVOD全文')}。\n\n"
    body += '> ' + q['quote'].replace('\n', '\n> ') + '\n\n' + q['context'] + '\n\n'
    body += f"日期：{q['date']}；會議：{q['venue']}。\n\n來源：{q['sourceType']}。\n\n"
    body += q['evidenceLocator'] + '\n\n' + q['recordingClockNote'] + '\n\n' + q['inferenceLimit'] + '\n\n'
    body += '純文字全文：' + q['sourceFile'] + '；SHA256：`' + sha256(source_bytes).hexdigest() + '`。\n\n'
    body += '\n'.join('- ' + external(q[key], label) for key, label in [('url', '官方全文'), ('videoUrl', '完整個人發言片段'), ('meetingInfoUrl', '會議目錄'), ('videoLocatorSource', '日期與影片長度目錄')] if q.get(key))
    note('原話', title, body, {'type': 'quote', 'date': q['date'], 'speaker': q['speaker'], 'verification': q['verificationLevel']})
note('索引', '索引-本人原話', '返回 ' + wiki(home) + '。\n\n' + quotes_data['selection'] + '\n\n' + '\n'.join(quote_links))

policy_links = []
for index, p in enumerate(policies, 1):
    ident = slug(p.get('id') or str(index))
    title = '政策-' + ident
    policy_links.append('- ' + wiki(title, p.get('title', ident)))
    category = p.get('mainTopic') or 'unclassified'
    body = '返回 ' + wiki(home) + '、' + wiki('索引-官網政策') + '、' + wiki('03 比較公式與職權差異') + '。\n\n'
    body += p.get('title', ident) + '\n\n' + p.get('summary', '') + '\n\n'
    body += '共同比較主題：' + category_names.get(category, category) + '。每頁等權，非子政策或預算占比。\n\n'
    body += external(p['url'], '官網原始政策頁') if p.get('url') else '來源URL待核對。'
    note('政策', title, body, {'type': 'policy', 'main_topic': category})
note('索引', '索引-官網政策', '返回 ' + wiki(home) + '、' + wiki('來源-候選人政策頁') + '。\n\n' + ('\n'.join(policy_links) if policies else '政策資料尚未完成編碼；目前不製造政策比較分數。資料完成後可重跑建置，補齊政策筆記。'))

# A spreadsheet-friendly public export is separate from the vault but uses the
# same immutable input rows. Escape active spreadsheet formula prefixes.
csv_buffer = io.StringIO(newline='')
writer = csv.writer(csv_buffer)
writer.writerow(['議案編號', '日期', '角色', '案名', '制度標的', '修法目的', '共同比較主題', '委員會', '進度', '原始來源'])
for b in bills:
    cells = [b['id'], b['date'], ROLES[b['role']], b['title'], b.get('targetTopic', ''), b.get('purposeTopic', ''), b.get('mainTopic') or 'unclassified', '；'.join(b.get('committees') or [PLACEHOLDER]), b.get('status', ''), b['url']]
    writer.writerow(["'" + str(v) if str(v).startswith(('=', '+', '-', '@')) else v for v in cells])

# Reject any unintended private package material without echoing matched values.
patterns = {
    'local_absolute_path': re.compile(r'(?<![A-Za-z0-9\\])[A-Za-z]:[\\/]|file[:][/][/]|[/]Users[/]|[/]home[/]'),
    'email_address': re.compile(r'[A-Za-z0-9._%+-]+@[A-Za-z0-9.-]+\.[A-Za-z]{2,}'),
    'private_credential': re.compile(r'\bsb_secret_[A-Za-z0-9_-]{12,}|\bgh[pousr]_[A-Za-z0-9]{20,}|\beyJ[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}\.[A-Za-z0-9_-]{16,}'),
    'deployment_metadata': re.compile(r'https?://[^\s"<>]+[.]chatgpt[.]site|admin[_]users|SUPABASE[_]SERVICE[_]ROLE[_]KEY'),
}
privacy = []
for path, content in entries.items():
    if path.endswith(('.html', '.pdf')) or '..' in Path(path).parts or Path(path).is_absolute():
        raise ValueError('Unapproved archive path: ' + path)
    text = content.decode('utf-8')
    for kind, pattern in patterns.items():
        count = len(pattern.findall(text))
        if count:
            privacy.append({'file': path, 'type': kind, 'count': count})
if privacy:
    raise ValueError('Privacy audit rejected file types/counts: ' + json.dumps(privacy, ensure_ascii=False))

links, missing = 0, []
for title, content in notes.items():
    for target in re.findall(r'\[\[([^\]|#]+)(?:[^\]]*)\]\]', content):
        links += 1
        if target not in notes:
            missing.append({'note': title, 'target': target})
if missing:
    raise ValueError('Unresolved Wiki links: ' + json.dumps(missing, ensure_ascii=False))
checksums = {'algorithm': 'SHA256', 'files': [{'path': path, 'bytes': len(content), 'sha256': sha256(content).hexdigest()} for path, content in sorted(entries.items())]}
put('checksums.json', encoded(checksums))

VAULT.mkdir(parents=True, exist_ok=True)
DOWNLOADS.mkdir(parents=True, exist_ok=True)
# Only builder-owned output files are overwritten. Remove stale builder-owned
# files listed in the prior manifest, after resolving every path inside VAULT.
previous = VAULT / 'checksums.json'
if previous.exists():
    for item in read_json(previous).get('files', []):
        old = VAULT / item['path']
        if old.resolve().is_relative_to(VAULT.resolve()) and item['path'] not in entries and old.is_file():
            old.unlink()
for path, content in entries.items():
    output = VAULT / path
    output.parent.mkdir(parents=True, exist_ok=True)
    output.write_bytes(content)
zip_path = DOWNLOADS / 'obsidian-vault.zip'
def build_zip():
    buffer = io.BytesIO()
    with zipfile.ZipFile(buffer, 'w', compression=zipfile.ZIP_DEFLATED, compresslevel=9) as archive:
        for path, content in sorted(entries.items()):
            info = zipfile.ZipInfo('蘇巧慧國會觀測知識庫/' + path, FIXED_TIME)
            info.compress_type = zipfile.ZIP_DEFLATED
            info.external_attr = 0o100644 << 16
            info.create_system = 3
            archive.writestr(info, content, compress_type=zipfile.ZIP_DEFLATED, compresslevel=9)
    return buffer.getvalue()
zip_bytes = build_zip()
assert zip_bytes == build_zip(), 'Nondeterministic ZIP content'
assert len(zip_bytes) < 25 * 1024 * 1024
with zipfile.ZipFile(io.BytesIO(zip_bytes)) as archive:
    assert archive.testzip() is None
zip_path.write_bytes(zip_bytes)
(DOWNLOADS / 'bills.csv').write_bytes(b'\xef\xbb\xbf' + csv_buffer.getvalue().encode('utf-8'))
report = {
    'person': '蘇巧慧', 'asOf': meta['end'], 'roles': dict(counts), 'uniqueBills': len(bills),
    'quotes': len(quotes), 'policies': len(policies), 'policyDataPresent': policy_path.exists(), 'codebookPresent': codebook_path.exists(),
    'quoteChecks': quote_checks,
    'notes': len(notes), 'wikiLinks': links, 'unresolvedWikiLinks': [], 'privacyFindings': [],
    'archiveFiles': len(entries), 'zipBytes': len(zip_bytes), 'zipSha256': sha256(zip_bytes).hexdigest(),
    'crcPassed': True, 'reproducible': True, 'under25MiB': True,
    'inputs': [{'file': 'data/' + path.name, 'sha256': sha256(path.read_bytes()).hexdigest()} for path in sorted(DATA.glob('*.json'))]
}
(ROOT / 'research' / 'su-vault-audit.json').write_bytes(encoded(report))
print(json.dumps(report, ensure_ascii=False))
