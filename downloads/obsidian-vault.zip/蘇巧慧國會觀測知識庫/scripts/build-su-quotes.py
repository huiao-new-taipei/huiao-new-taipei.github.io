"""Nine independently sourced official Su speech excerpts; no invented seconds."""
from pathlib import Path
import json,re,html,hashlib,datetime
ROOT=Path(__file__).resolve().parents[1];SRC=ROOT/'research/su-sources';OUT=ROOT/'site/dist/data'
NOM='2025-11-26'
SEEDS=[
 (152739,'都市更新優惠貸款的政策工具','你今天如果真的要做到優惠的感覺，你就是利率的差異要做出來，讓人家覺得我願意來這裡，這裡更好，這才是有效的政策工具嘛！','住宅與都市更新','政策質詢','她先以模擬質詢批評當時國會改革條文的適用範圍，再轉入都市更新優惠貸款的實質詢答。本句針對政府貸款利率和民間金融機構差異不大，主張檢討利率、貸款年限與可申請階段，不是對所有貸款的概括評論。'),
 (152842,'文化獨特性與產業發展','我們在保有自己文化獨特性的同時，也一定要讓產業能夠同步進行，兩隻腳、兩軌並行，文化才能夠真正地落實在臺灣的每個面向。','文化與產業','政策主張','文化部長李遠首次備詢時，她討論兒少節目、校外文化體驗、出版品公共借閱權及文策院產業投資，主張文化內容與產業資金兩軌並進。此句是政策方向，不是已完成成效的證明。'),
 (153103,'三讀程序中的「鴨霸」批評','這最後的3分鐘，再讓我們看出來國民黨是多麼的「鴨霸」！','國會程序與政治批評','政治批評','她在立法院職權行使法三讀後發言，批評最後修正案資料發送及表決程序，並主張修正超出文字調整。引文是針對國民黨議事操作的政治批評；其黑箱、擴權等說法屬她當時的判斷，不能直接當作已裁判的法律結論或人格證據。'),
 (161042,'都市更新審議「請支援收銀」','現在簡單講就像是要去付錢的人太多，結果收銀臺塞住了，所以廣播「請支援收銀」嘛！','住宅與都市更新','比喻與政策質詢','她認為都更送案件數增加，但地方都委會、交評及環評等審議量能造成塞車，要求內政部提出指引、鼓勵併審及增加審議量能。「收銀臺」是對審議流程的比喻，不是描述零售業員工。'),
 (161365,'消防裝備研究委外的期程追問','好，我同意你委外，但是期程呢？在備詢臺直接回答。','消防與公共安全','政策追問','她追蹤消防車輛、裝備及人力配置客觀標準，得知消防署將委外研究國外資料後，表示可接受委外，但要求明確起訖時間；署長回覆當年度可有初步成果。不能把這句解讀成反對委外研究。'),
 (161475,'死刑一致決公投的題意爭議','這一案根本不能簡稱為反廢死，因為第一，臺灣沒有廢死，何來廢死公投？','憲政、死刑與公投','法律與政治主張','發言針對「各級法院合議庭法官判處死刑不須一致決」公投案。她區分一致決程序與是否廢除死刑，主張該題無論通過與否都不會直接產生廢除死刑的效果，並質疑與憲法判決相容性。單憑本句不能歸結她個人的廢死立場。'),
 (170829,'要求陸委會提供客觀資訊','我希望陸委會能夠更客觀地提供更多的事實，不斷給國人參考。','兩岸交流與資訊','政策主張','她就中國出入境規定變動及赴中風險質詢，要求陸委會提供清楚資訊，並說明由人民自行判斷交流及旅遊決定。引文能證明她提出資訊揭露要求；不等同本站已逐一獨立查證發言中的外國法規、新聞或風險判斷。'),
 (170942,'包租代管與「政府做東」','正是因為有很多是大房東，所以需要政府做東。','租屋與包租代管','政策比喻','她建議針對高齡長者及大學生設計包租代管專案，讓政府協助建立可信的房源、契約與租金安排，回應大學附近大房東是否願意加入的問題。「政府做東」在此指政府協調的平台角色，不是主張沒收房產。'),
 (171032,'支持原住民族學校與現階段實驗教育','我的結論是，我支持有原住民族學校，但我要求在現階段更大力地支持原住民族實驗教育學校，請告訴我們支持的方向，謝謝。','原住民族教育','附條件政策主張','教育及文化、內政聯席會議討論原住民族學校法草案時，她支持設校方向，但追問族語師資、課程研發及行政分工，要求先補足實驗教育學校資源與跨區同族別課程合作。不能剪成她反對原住民族學校。'),
]
directory={}
for path in SRC.glob('ivod-directory-page-*.html'):
 s=path.read_text(encoding='utf-8-sig')
 for li in re.findall(r'<li\b[^>]*>.*?</li>',s,re.S):
  ident=re.search(r'/Play/Clip/1M/(\d+)',li)
  if not ident:continue
  text=re.sub(r'\s+',' ',html.unescape(re.sub('<[^>]+>',' ',li))).strip()
  date=re.search(r'會議時間：\s*(\d{4}-\d{2}-\d{2})',text)
  committee=re.search(r'<h3[^>]*>.*?主辦單位：\s*([^<]+)',li,re.S)
  clock=re.search(r'委員發言時間：\s*(\d\d:\d\d:\d\d) - (\d\d:\d\d:\d\d)',text)
  duration=re.search(r'影片長度：\s*(\d\d:\d\d:\d\d)',text)
  meeting=re.search(r'href="(https://ppg.ly.gov.tw/ppg/sittings/[^\"]+)"',li)
  if date:directory[int(ident[1])]={'ivod_id':int(ident[1]),'date':date[1],'committee':html.unescape(committee[1]).strip() if committee else None,
   'recordingClock':'–'.join(clock.groups()) if clock else None,'duration':duration[1] if duration else None,'text':text,
   'sourceFile':'research/su-sources/'+path.name,'meetingInfoUrl':html.unescape(meeting[1]) if meeting else None,
   'directoryUrl':'https://ivod.ly.gov.tw/Demand/ListLgltVideo/7320'+('?page='+re.search(r'page-(\d+)',path.name)[1] if 'page-1.' not in path.name else '')}
quotes=[];checks=[]
for ident,title,quote,topic,kind,context in SEEDS:
 meta=directory[ident];assert '2024-02-01'<=meta['date']<='2026-10-20'
 path=SRC/f'speech-{ident}.txt';source=path.read_text(encoding='utf-8');positions=[i for i,c in enumerate(source) if not c.isspace()]
 flat=''.join(source[i] for i in positions);needle=re.sub(r'\s+','',quote);start=flat.find(needle);assert start>=0,(ident,quote)
 pos=positions[start];end=positions[start+len(needle)-1]+1
 tags=list(re.finditer(r'(?m)^(主席|蘇委員巧慧|[\u4e00-\u9fff]{1,2}(?:副主任委員|主任委員|副局長|副署長|次長|部長|院長|局長|署長|處長|委員|董事長)[\u4e00-\u9fff]{1,4})：',source[:pos+1]));assert tags and tags[-1][1]=='蘇委員巧慧',(ident,tags[-1][1] if tags else None)
 first=source.count('\n',0,pos)+1;last=source.count('\n',0,end)+1
 venue=meta['text'].split('會議名稱：',1)[-1].split('（事由：',1)[0].strip()
 meeting_id=(meta['meetingInfoUrl'] or '').split('/sittings/')[-1].split('/')[0] if meta['meetingInfoUrl'] else str(ident)
 q={'id':f'su-official-{ident}','eventId':'su-meeting-'+meeting_id,'ivodId':ident,'title':title,'speaker':'蘇巧慧','quote':quote,
 'date':meta['date'],'eventDate':meta['date'],'datePrecision':'day-official-directory','nominationPhase':'before' if meta['date']<NOM else 'after',
 'period':'pre' if meta['date']<NOM else 'post','medium':'spoken','topic':topic,'quoteKind':kind,'venue':venue,
 'frontContext':context.split('。')[0]+'。','context':context,'sourceType':'立法院官方iVOD全文發言紀錄；官方影片目錄交叉核日，未另核聽原聲',
 'verificationLevel':'official-transcript-fulltext','url':f'https://ivod.ly.gov.tw/Demand/Speech/{ident}',
 'sourceURL':f'https://ivod.ly.gov.tw/Demand/Speech/{ident}','videoUrl':f'https://ivod.ly.gov.tw/Play/Clip/1M/{ident}',
 'videoLabel':'完整個人發言片段','videoDuration':meta['duration'],'recordingClock':meta['recordingClock'],'recordingClockNote':'官方目錄的整段會議時鐘起訖；不是句內影片秒數。',
 'fullVideoUrl':None,'meetingInfoUrl':meta['meetingInfoUrl'],'videoLocatorSource':meta['directoryUrl'],
 'sourceFile':str(path.relative_to(ROOT)).replace('\\','/'),'sourceHtmlFile':str(path.with_suffix('.html').relative_to(ROOT)).replace('\\','/'),
 'sourceLineStart':first,'sourceLineEnd':last,'localDateEvidence':meta['sourceFile'],
 'evidenceLocator':f'保存全文第{first}–{last}行，蘇委員巧慧發言段；搜尋引文即可定位。官方目錄列完整片段{meta["recordingClock"]}，片長{meta["duration"]}，尚未核句內秒數。',
 'quizEligible':True,'useInQuiz':True,'archiveTier':'featured','editorialRank':len(quotes)+1,
 'inferenceLimit':'僅確認引文、說話者及語境；精選案例不代表平日言論比例，也不能單憑言論推斷人格真假或隱藏動機。'}
 quotes.append(q);checks.append({'id':q['id'],'normalizedQuoteFound':True,'speakerVerified':True,'officialDirectoryDateVerified':True,'verifiedAudioSeconds':False,
  'textSha256':hashlib.sha256(path.read_bytes()).hexdigest()})
data={'version':'su-v1','nominationDate':NOM,'nominationSource':'https://www.dpp.org.tw/content_print/media/11384',
 'selection':'9個官方完整發言片段的精選短引文，跨2024–2026年。來源型態與政策/政治見解分開標示；不是言論頻率的隨機樣本。',
 'quotes':quotes,'counts':{'verified':len(quotes),'total':len(quotes),'spoken':len(quotes),'written':0,'events':len(set(q['eventId'] for q in quotes))},
 'quizCounts':{'total':len(quotes),'before':sum(q['nominationPhase']=='before' for q in quotes),'after':sum(q['nominationPhase']=='after' for q in quotes)},
 'comparisons':[],'pending':[],'updatedAt':datetime.datetime.now(datetime.timezone.utc).isoformat()}
(OUT/'quotes.json').write_text(json.dumps(data,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(ROOT/'research/su-quote-verification.json').write_text(json.dumps({'checks':checks,'audioSecondsInvented':False,'officialTranscriptCount':len(quotes)},ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
(SRC/'ivod-directory-sample.json').write_text(json.dumps(list(directory.values()),ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({'counts':data['counts'],'quizCounts':data['quizCounts'],'speakerChecks':len(checks)},ensure_ascii=False))
