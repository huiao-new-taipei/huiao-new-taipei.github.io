---
---

# 來源-立法院議案API

返回 [[00 蘇巧慧國會觀測知識庫]]、[[04 來源與驗證方法]]。

[立法院本人提案API](https://www.ly.gov.tw/WebAPI/LegislativeBill.aspx?from=1130201&to=1151020&proposer=%E8%98%87%E5%B7%A7%E6%85%A7&mode=json)。主提39、共提30與保存清單一致。research/su-role-crosscheck.json 保存逐案差異，原始議案附件優先。
