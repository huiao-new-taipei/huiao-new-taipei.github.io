---
---

# 來源-LYAPI結構化清單

返回 [[00 蘇巧慧國會觀測知識庫]]、[[04 來源與驗證方法]]。

[LYAPI人物端點](https://ly.govapi.tw/v2/legislators/11/%E8%98%87%E5%B7%A7%E6%85%A7)。提案／連署原回應附於 research/su-sources/；抓取URL、時間、狀態、bytes、SHA256見 research/su-sources/provenance.json。此服務是結構化鏡像，不能取代官方原件。
