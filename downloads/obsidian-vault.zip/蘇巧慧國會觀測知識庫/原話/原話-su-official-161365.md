---
type: "quote"
date: "2025-05-14"
speaker: "蘇巧慧"
verification: "official-transcript-fulltext"
---

# 原話-su-official-161365

返回 [[00 蘇巧慧國會觀測知識庫]]、[[索引-本人原話]]、[[來源-官方iVOD全文]]。

> 好，我同意你委外，但是期程呢？在備詢臺直接回答。

她追蹤消防車輛、裝備及人力配置客觀標準，得知消防署將委外研究國外資料後，表示可接受委外，但要求明確起訖時間；署長回覆當年度可有初步成果。不能把這句解讀成反對委外研究。

日期：2025-05-14；會議：立法院第11屆第3會期內政委員會第19次全體委員會議。

來源：立法院官方iVOD全文發言紀錄；官方影片目錄交叉核日，未另核聽原聲。

保存全文第77–77行，蘇委員巧慧發言段；搜尋引文即可定位。官方目錄列完整片段10:34:56–10:42:28，片長00:07:32，尚未核句內秒數。

官方目錄的整段會議時鐘起訖；不是句內影片秒數。

僅確認引文、說話者及語境；精選案例不代表平日言論比例，也不能單憑言論推斷人格真假或隱藏動機。

純文字全文：research/su-sources/speech-161365.txt；SHA256：`006e3f8cdfbf979f4684d2db95a3aab08cde329a149701f9ec0cd98892706dd2`。

- [官方全文](https://ivod.ly.gov.tw/Demand/Speech/161365)
- [完整個人發言片段](https://ivod.ly.gov.tw/Play/Clip/1M/161365)
- [會議目錄](https://ppg.ly.gov.tw/ppg/sittings/2025050934/details?meetingDate=114%2F05%2F14)
- [日期與影片長度目錄](https://ivod.ly.gov.tw/Demand/ListLgltVideo/7320?page=12)
