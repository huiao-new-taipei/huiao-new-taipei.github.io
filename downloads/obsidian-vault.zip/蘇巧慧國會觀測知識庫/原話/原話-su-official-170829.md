---
type: "quote"
date: "2026-08-05"
speaker: "蘇巧慧"
verification: "official-transcript-fulltext"
---

# 原話-su-official-170829

返回 [[00 蘇巧慧國會觀測知識庫]]、[[索引-本人原話]]、[[來源-官方iVOD全文]]。

> 我希望陸委會能夠更客觀地提供更多的事實，不斷給國人參考。

她就中國出入境規定變動及赴中風險質詢，要求陸委會提供清楚資訊，並說明由人民自行判斷交流及旅遊決定。引文能證明她提出資訊揭露要求；不等同本站已逐一獨立查證發言中的外國法規、新聞或風險判斷。

日期：2026-08-05；會議：立法院第11屆第5會期內政委員會第22次全體委員會議。

來源：立法院官方iVOD全文發言紀錄；官方影片目錄交叉核日，未另核聽原聲。

保存全文第83–83行，蘇委員巧慧發言段；搜尋引文即可定位。官方目錄列完整片段09:42:19–09:53:33，片長00:11:14，尚未核句內秒數。

官方目錄的整段會議時鐘起訖；不是句內影片秒數。

僅確認引文、說話者及語境；精選案例不代表平日言論比例，也不能單憑言論推斷人格真假或隱藏動機。

純文字全文：research/su-sources/speech-170829.txt；SHA256：`fbf7ff764b63b9a5e3148c790b84fa7ab16036b68302dcfef5a4d29ba9ee34e2`。

- [官方全文](https://ivod.ly.gov.tw/Demand/Speech/170829)
- [完整個人發言片段](https://ivod.ly.gov.tw/Play/Clip/1M/170829)
- [會議目錄](https://ppg.ly.gov.tw/ppg/sittings/2026073125/details?meetingDate=115%2F08%2F05)
- [日期與影片長度目錄](https://ivod.ly.gov.tw/Demand/ListLgltVideo/7320)
