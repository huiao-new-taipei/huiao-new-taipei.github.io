---
type: "quote"
date: "2026-08-12"
speaker: "蘇巧慧"
verification: "official-transcript-fulltext"
---

# 原話-su-official-170942

返回 [[00 蘇巧慧國會觀測知識庫]]、[[索引-本人原話]]、[[來源-官方iVOD全文]]。

> 正是因為有很多是大房東，所以需要政府做東。

她建議針對高齡長者及大學生設計包租代管專案，讓政府協助建立可信的房源、契約與租金安排，回應大學附近大房東是否願意加入的問題。「政府做東」在此指政府協調的平台角色，不是主張沒收房產。

日期：2026-08-12；會議：立法院第11屆第5會期內政委員會第23次全體委員會議。

來源：立法院官方iVOD全文發言紀錄；官方影片目錄交叉核日，未另核聽原聲。

保存全文第66–66行，蘇委員巧慧發言段；搜尋引文即可定位。官方目錄列完整片段10:41:25–10:52:15，片長00:10:50，尚未核句內秒數。

官方目錄的整段會議時鐘起訖；不是句內影片秒數。

僅確認引文、說話者及語境；精選案例不代表平日言論比例，也不能單憑言論推斷人格真假或隱藏動機。

純文字全文：research/su-sources/speech-170942.txt；SHA256：`fa2530eb59f950d55410c86eaecae01edeffd0f6de5e06815605a6e4d1c56c0b`。

- [官方全文](https://ivod.ly.gov.tw/Demand/Speech/170942)
- [完整個人發言片段](https://ivod.ly.gov.tw/Play/Clip/1M/170942)
- [會議目錄](https://ppg.ly.gov.tw/ppg/sittings/2026080768/details?meetingDate=115%2F08%2F12)
- [日期與影片長度目錄](https://ivod.ly.gov.tw/Demand/ListLgltVideo/7320)
