# 郭台銘政見／性別批評

- [[原話/su-guo-gender-zero-202309-candidate-v7|性別意識零分、頻頻口出狂言]] — 蘇巧慧／2023-09
- [[原話/su-guo-gender-fail-202309-candidate-v7|性別意識幾乎死當]] — 蘇巧慧／2023-09
