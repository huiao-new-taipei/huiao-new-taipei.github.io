# 傅崐萁提案用詞爭議

- [[原話/su-fu-abandon-country-20240502-candidate-v7|連國家都不要了]] — 蘇巧慧／2024-05-02
- [[原話/su-fu-pacific-retreat-20240501-candidate-v7|是要從花蓮一路退到太平洋了嗎？]] — 蘇巧慧／2024-05-01
