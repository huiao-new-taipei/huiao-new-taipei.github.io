---
id: "su-boring-shameful-20250101"
eventId: "su-procurement-response-20250102"
caseId: "wang-family-procurement-20250102"
speaker: "蘇巧慧"
date: "2025-01-01"
datePrecision: "report-date-upper-bound"
medium: "reported"
quizEligible: false
audioVerified: false
---

# 回應家人採購質疑的前一日措辭

> 既無聊、又可恥

2025年1月1日回應王鴻薇即將召開記者會；與1月2日既有「可恥又可悲」放在同一採購攻防群組，避免同輪重複事件。

來源：[又被王鴻薇指「大翻車」 蘇巧慧反擊：被打臉還不痛定思痛](https://www.nownews.com/news/6627309)

新聞以蘇巧慧回應／強調歸屬措辭，未取得本人聲明原件或核聽

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/wang-family-procurement-20250102|回到事件]]
