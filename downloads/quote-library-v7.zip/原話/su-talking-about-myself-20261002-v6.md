---
id: "su-talking-about-myself-20261002-v6"
eventId: "su-zhang-response-20261002"
caseId: "zhang-shujuan-2022-2026"
speaker: "蘇巧慧"
date: "2026-10-02"
datePrecision: "day-contemporaneous-news"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 被追問舊節目發言時的解釋

> 這完全是在講我自己

張淑娟點名她、韋淳祐公布舊節目錄音後，她在2026年10月2日受訪，主張當年是在談從政者面臨選舉檢驗，包括她自己，並說從政以來不談他人私事。此題呈現她的回應，不把被害人或政治對手的指控轉成她的自認。

來源：[原文](https://udn.com/news/story/124652/9790707)

同日聯合報採訪正文以引號直接引述；未逐句核聽原聲。

這是澄清用語，並非罵人或粗俗發言。可和舊節目完整脈絡對照，不能只靠這句判定她說謊，也不能把周玉蔻、蔡玉真的司法責任移到她身上。2022年舊節目與2026年回應須區分日期，不拆重複回應充數。

[[案例/zhang-shujuan-2022-2026|回到事件]]
