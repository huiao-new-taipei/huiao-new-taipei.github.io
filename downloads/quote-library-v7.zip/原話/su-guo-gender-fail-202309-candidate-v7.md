---
id: "su-guo-gender-fail-202309-candidate-v7"
eventId: "su-guo-child-pet-policy-gender-202309"
caseId: "su-guo-child-pet-policy-gender-202309"
speaker: "蘇巧慧"
date: "2023-09"
datePrecision: "month-original-post-date-unconfirmed; contemporary-report-2023-09-02"
medium: "written"
quizEligible: true
audioVerified: false
---

# 對郭團隊用上「死當」

> 性別意識幾乎死當

同篇臉書貼文的媒體引述後段，主詞由郭的表現轉到郭的團隊；『死當』是她以成績作比喻的批評。不能抽成針對兒童、女性或一般選民的辱罵，也不是又一個獨立事件。

來源：[蘇巧慧：郭台銘政見荒腔走板、大開民主倒車 絕不是能領導台灣的人](https://newtalk.tw/news/view/2023-09-02/886768)

同時期媒體引述本人臉書貼文；原貼日依本題標示

主詞是她批評的郭團隊；需保留這個對象。；同貼文兩短句不能當成兩個事件。；未核原貼或原聲，不用作聲音逐字辨識題。

[[案例/su-guo-child-pet-policy-gender-202309|回到事件]]
