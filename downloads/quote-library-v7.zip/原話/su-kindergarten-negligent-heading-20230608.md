---
id: "su-kindergarten-negligent-heading-20230608"
eventId: "su-kindergarten-20230608-post"
caseId: "kindergarten-2023-2026"
speaker: "蘇巧慧"
date: "2023-06-08"
datePrecision: "day"
medium: "written"
quizEligible: false
audioVerified: false
---

# 同篇對市府處理的批評

> 侯市府反應輕忽怠慢

同篇原貼第2點標題，針對市府窗口、資訊、檢驗安排及家長求助的批評。

來源：[蘇巧慧：令人憤怒的餵毒案件](https://www.facebook.com/chiaohui.su/posts/pfbid0A5p8qjGrJML1fQxpgW6CWikVgZjjCSxbF8iXWvjDBkR3BdpZuEzsoaQdi8MxDfLjl)

本人原始公開 Facebook 貼文

監察院之後確實另有行政糾正；這句不能不加區分地列為已證偽陳述。；同篇僅一事件。

[[案例/kindergarten-2023-2026|回到事件]]
