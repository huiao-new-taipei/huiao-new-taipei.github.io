---
id: "investment-no-intervention-20260604"
eventId: "su-investment-interview-20260604"
caseId: "quantum-investment-grant-2022-2026"
speaker: "蘇巧慧"
date: "2026-06-04"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 聲稱不干預妹妹工作

> 我也從不干預她的工作

回應民眾黨議員參選人赴監察院告發。華視把本句連在『她做的不是違法的事』之後，接著是本人不怕檢驗及正面選戰說法。不是對投資程序的獨立查核結論。

來源：[民眾黨議員參選人質疑補助未依法申報 蘇巧慧：不怕檢驗](https://news.cts.com.tw/cts/politics/202606/202606043040049.html)

新聞影片出版者文字逐字引述

只能確認她如此宣稱；未取得直接證據證明她有或沒有介入投資/補助。；本輪已找到新聞原頁所嵌影片，未核音/時間點。

[[案例/quantum-investment-grant-2022-2026|回到事件]]
