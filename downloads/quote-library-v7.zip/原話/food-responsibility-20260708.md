---
id: "food-responsibility-20260708"
eventId: "su-food-interview-20260708"
caseId: "food-oil-2026"
speaker: "蘇巧慧"
date: "2026-07-08"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 對毒油責任分工的說明

> 中央和地方各自負起責任，一起把事情做好。

面對李四川質疑未對中聯油品表態，蘇說應依食安法分工，包含流向/源頭調查及下架。這句本身沒有說中央免責；不能裁成只剩『地方負責』。

來源：[被質疑油品議題沒發聲 蘇巧慧：中央地方一起把事做好](https://udn.com/news/story/124652/9614652)

當時受訪報導

未核對原聲逐句起迄；不能標為已核音。

[[案例/food-oil-2026|回到事件]]
