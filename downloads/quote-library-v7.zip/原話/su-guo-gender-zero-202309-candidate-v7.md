---
id: "su-guo-gender-zero-202309-candidate-v7"
eventId: "su-guo-child-pet-policy-gender-202309"
caseId: "su-guo-child-pet-policy-gender-202309"
speaker: "蘇巧慧"
date: "2023-09"
datePrecision: "month-original-post-date-unconfirmed; contemporary-report-2023-09-02"
medium: "written"
quizEligible: true
audioVerified: false
---

# 批評郭台銘的性別意識

> 性別意識零分、頻頻口出狂言

Newtalk於2023-09-02引述她的臉書貼文，對郭提出生孩子與養寵物相連的想法、團隊人選及性別相關言論提出批評，並比較民進黨少子化措施。此短句修飾郭的競選表現，是她的政治評價，不是學術量表得分。

來源：[蘇巧慧：郭台銘政見荒腔走板、大開民主倒車 絕不是能領導台灣的人](https://newtalk.tw/news/view/2023-09-02/886768)

同時期媒體引述本人臉書貼文；原貼日依本題標示

書面貼文不得標成已確認本人口說。；媒體頁日期已核，原貼精確日期未核；只確定2023年9月，不能偽填具體日。；文章內對郭的其他指控與引述未逐項核實，不隨本短句一併當作事實採用。；屬公開政策與政治人物的強烈批評，不直接等於她對一般人的態度或人格結論。

[[案例/su-guo-child-pet-policy-gender-202309|回到事件]]
