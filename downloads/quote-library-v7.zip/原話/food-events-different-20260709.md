---
id: "food-events-different-20260709"
eventId: "su-food-interview-20260709"
caseId: "food-oil-2026"
speaker: "蘇巧慧"
date: "2026-07-09"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 被問到父親過去的食安說法

> 我想這兩個事件其實是不一樣的

被問及父親2014年要求中央負責的舊貼文，蘇先區分飼料油混充與此次事件，再談分工。這是同次回應的一句，不能算另一個事件。

來源：[致癌油蘇巧慧稱中央地方各自負責 川辦酸「雙標」](https://news.cts.com.tw/cts/politics/202607/202607093053664.html)

新聞影片出版者文字逐字引述

未核對原聲逐句起迄；不能標為已核音。

[[案例/food-oil-2026|回到事件]]
