---
id: "su-hou-learn-ma-20230527"
eventId: "su-hou-ma-20230527"
caseId: "su-hou-ma-20230527"
speaker: "蘇巧慧"
date: "2023-05-27"
datePrecision: "report-date-upper-bound"
medium: "written"
quizEligible: true
audioVerified: false
---

# 評論侯友宜拜會馬英九

> 所以我實在不知道落跑參選總統的侯友宜市長要去向馬英九學習什麼？

報導刊她評論侯友宜向馬英九請益的臉書內容；其對馬施政的評價屬政治主張，未當作客觀排行榜。

來源：[侯友宜會馬英九 蘇巧慧：實在不知道落跑參選的要向最差的學習什麼](https://newtalk.tw/news/view/2023-05-27/873094)

報導以「蘇巧慧表示」及引號刊登；原貼日未另核

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/su-hou-ma-20230527|回到事件]]
