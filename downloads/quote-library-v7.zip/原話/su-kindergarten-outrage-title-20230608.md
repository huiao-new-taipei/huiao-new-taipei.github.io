---
id: "su-kindergarten-outrage-title-20230608"
eventId: "su-kindergarten-20230608-post"
caseId: "kindergarten-2023-2026"
speaker: "蘇巧慧"
date: "2023-06-08"
datePrecision: "day"
medium: "written"
quizEligible: true
audioVerified: false
---

# 原貼把案件稱作「餵毒」

> 令人憤怒的餵毒案件

原貼標題；偵查尚未終結。她稱收到家長陳情並整理當時採檢與市府處理資訊。

來源：[蘇巧慧：令人憤怒的餵毒案件](https://www.facebook.com/chiaohui.su/posts/pfbid0A5p8qjGrJML1fQxpgW6CWikVgZjjCSxbF8iXWvjDBkR3BdpZuEzsoaQdi8MxDfLjl)

本人原始公開 Facebook 貼文

此題只驗證她如此定調，不證明幼兒園實際餵毒。；與同貼其他句同事件，不增加事件數。

[[案例/kindergarten-2023-2026|回到事件]]
