---
id: "investment-crime-comparison-20260526"
eventId: "su-investment-interview-20260526"
caseId: "quantum-investment-grant-2022-2026"
speaker: "蘇巧慧"
date: "2026-05-26"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 拿對手家人案件作比較

> 跟別人竊占國土、盜採砂石、恐嚇他人這種犯罪行為，是完全不一樣的

中央社文末以直接引號記錄蘇在替妹妹專業工作辯護後，拿對手家人涉及的案件作比較。後文蘇提對手家人在法庭認罪、年領600萬報導與指控時機；不是她在承認妹妹犯罪。

來源：[民眾黨指胞妹未利益迴避 蘇巧慧：她靠專業發光發熱](https://www.cna.com.tw/news/aipl/202605260106.aspx)

本人受訪及具名指控報導

這段可核對尖銳比較用語；不是已證明曠世案合法的外部結論。；本輪未另核她所指對手家人案件原判決，不把引句中的犯罪描述當本站已完成法律認定。

[[案例/quantum-investment-grant-2022-2026|回到事件]]
