---
id: "su-children-classmates-20240528-v6"
eventId: "su-national-assembly-20240528-153103"
caseId: "children-colleagues-20240528"
speaker: "蘇巧慧"
date: "2024-05-28"
datePrecision: "day-official-directory"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 批評立法時，談到對方的孩子

> 你的孩子也是念法律系的吧！你好意思讓他去面對同學嗎？

她在國會職權修法三讀後批評程序及立法品質，先稱國民黨、民眾黨委員，再提到法律系學生與對方孩子如何面對同學。原段未具名指向某位委員或特定子女。這題辨認原話與批評範圍，不把她對法案的判斷當成法律定論。

來源：[原文](https://ivod.ly.gov.tw/Demand/Speech/153103)

立法院官方全文既存保存；本輪再以報導者同一iVOD逐字稿交叉核對。未逐句核聽原聲。

同場『鴨霸』與這段子女用語屬同一事件，不能拆成同輪兩個獨立事件。原段未點名特定孩子，不能自行補上姓名，也不能由這一句推定人格或隱藏動機。

[[案例/children-colleagues-20240528|回到事件]]
