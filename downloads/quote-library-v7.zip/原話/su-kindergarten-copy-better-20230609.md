---
id: "su-kindergarten-copy-better-20230609"
eventId: "su-kindergarten-20230609-presser"
caseId: "kindergarten-2023-2026"
speaker: "蘇巧慧"
date: "2023-06-09"
datePrecision: "day"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 同場譏諷侯友宜的育兒政策

> 要抄也抄好一點好嗎？

同場批評侯友宜提出零到六歲國家養，認為蔡英文政府已在推動相關政策。這一句是對侯政策的譏諷，不是指學術論文抄襲。

來源：[孩子中毒不重要？民進黨批侯友宜只顧選舉拉票：新北幼兒園餵毒案，宛如恩恩案翻版](https://watchout.tw/reports/v0s8YDGsKcXzg38Bv68s)

當日現場採訪報導，正文以引號直接記錄

與同場其他句只算一事件。；『抄』的對象是政策，不能混入管中閔論文案。；本人是否針對這句另回應未取得。

[[案例/kindergarten-2023-2026|回到事件]]
