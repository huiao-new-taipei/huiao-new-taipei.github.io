---
id: "food-no-evasion-20260722"
eventId: "su-food-interview-20260722"
caseId: "food-oil-2026"
speaker: "蘇巧慧"
date: "2026-07-22"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 回應沒有發聲的批評

> 面對問題也從不迴避

7/22板橋龍興市場本人受訪回應『神隱21天』指控。此為記者歸述用語，尚不能當逐字字幕；與7/21競辦夷將先行回應分開。

來源：[藍營指神隱 蘇巧慧：幾乎每天都有公開行程、從未迴避](https://udn.com/news/story/7323/9643053)

本人受訪報導

記者間接引述；有7/8與7/9回應紀錄，因此不能不加條件斷言整整21天從未發聲。；尚未取得可檢驗所有公開行程及受訪的完整清單。

[[案例/food-oil-2026|回到事件]]
