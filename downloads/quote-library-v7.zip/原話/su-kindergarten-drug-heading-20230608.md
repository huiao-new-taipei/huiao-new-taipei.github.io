---
id: "su-kindergarten-drug-heading-20230608"
eventId: "su-kindergarten-20230608-post"
caseId: "kindergarten-2023-2026"
speaker: "蘇巧慧"
date: "2023-06-08"
datePrecision: "day"
medium: "written"
quizEligible: true
audioVerified: false
---

# 原貼把驗出藥物稱為毒品

> 孩子體內驗出的藥物，是 #毒品

同篇原貼第1點標題；下文援引當時28名採檢、8名藥物反應的資訊，並將藥物分級敘述為第三、第四級毒品。後續確認檢驗與首次不起訴發生在其後。

來源：[蘇巧慧：令人憤怒的餵毒案件](https://www.facebook.com/chiaohui.su/posts/pfbid0A5p8qjGrJML1fQxpgW6CWikVgZjjCSxbF8iXWvjDBkR3BdpZuEzsoaQdi8MxDfLjl)

本人原始公開 Facebook 貼文；同日FTNN轉載相互印證

檢驗反應與已證實服用毒品不可畫等號。；不得依她原貼的分級字樣直接當醫藥或司法事實；需呈現檢方後來說明。

[[案例/kindergarten-2023-2026|回到事件]]
