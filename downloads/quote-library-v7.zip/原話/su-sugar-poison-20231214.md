---
id: "su-sugar-poison-20231214"
eventId: "su-hou-housing-20231214"
caseId: "su-hou-housing-20231214"
speaker: "蘇巧慧"
date: "2023-12-14"
datePrecision: "report-date-upper-bound"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 批評零頭期購屋政策的比喻

> 包著糖衣的毒藥

她質疑侯友宜青年購屋政策前期免頭期與後期月付負擔。這是政策批評的比喻，與幼兒園案件無關。

來源：[侯友宜拋「青年購屋政策」免頭期 網友起底趙少康過去言論 嗆：根本打臉自己](https://finance.ftvnews.com.tw/news/detail/2023C14P04M1)

新聞文字以「立委（民）蘇巧慧」明確分配受訪原句，尚未核聽

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/su-hou-housing-20231214|回到事件]]
