---
id: "food-process-20260709"
eventId: "su-food-interview-20260709"
caseId: "food-oil-2026"
speaker: "蘇巧慧"
date: "2026-07-09"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 事件初期對問題來源的歸因

> 台中在地的製造商在製程出了問題

媒體將此措辭歸於蘇7/9本人，前句談2014進口飼料油混充、中央責任較多；後句仍要求中央/地方各負權責、檢討通報。7/27官方調查後可檢驗其早期歸因是否過於簡化，不能倒寫她7/9已知7/27調查結果。

來源：[被酸「你爸當年不是這樣說」！蘇巧慧回擊毒油案：兩件事不同](https://news.tvbs.com.tw/politics/3252678)

當時受訪報導

TVBS以受訪間接引述列出這串文字；華視同期直接引號在製造商與製程間有停頓、語助詞。若製作精準字幕應先核音。；後續專家報告支持原料風險與管理缺失多因交互作用；沒有直接設備設計造成BaP的證據，不等於完全沒有製程管控問題。

[[案例/food-oil-2026|回到事件]]
