---
id: "su-zhang-face-handle-explain-20220922-candidate-v7"
eventId: "su-hotnews152-zhang-20220922"
caseId: "zhang-shujuan-2022-2026"
speaker: "蘇巧慧"
date: "2022-09-22"
datePrecision: "day-secondary-program-date-not-audio-verified"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 節目接話：面對、處理、說清楚

> 面對它、處理它，跟社會說清楚

短句接在她認為事情到來時以直球對決處理的回答後。這是同一段話的後半部，不是另一事件。主持人當時談蔣家與張淑娟，蘇在2026則說以自己說明政治人物面對檢驗；未聽完整原段前，不將建議受詞斷定為她直接要求張淑娟證明清白。

來源：[遭張淑娟點名是幫凶　蘇巧慧：我從頭到尾都沒評論別人私事](https://news.tvbs.com.tw/politics/4030633)

媒體引述舊節目錄音；完整原音待核

與家族檢驗句是同一段回答，不增加事件數。；不把她的處理建議改寫成她本人重述主持人的性緋聞指控。；不能只留下四字標語；公開採用時需保留問題情境與2026本人回應。

[[案例/zhang-shujuan-2022-2026|回到事件]]
