---
id: "su-fu-abandon-country-20240502-candidate-v7"
eventId: "su-fu-china-mainland-wording-20240501-02"
caseId: "su-fu-china-mainland-wording-20240501-02"
speaker: "蘇巧慧"
date: "2024-05-02"
datePrecision: "day-broadcaster-contemporary-interview-script-not-audio-verified"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 把改提案用詞形容為不要國家

> 連國家都不要了

民視2024-05-02新聞稿逐字引述她拿著提案書，批評前一天要求把我國改成台灣、中國改成大陸。短句前面在談『我國』被改掉；不是在承認自己或一般民眾不要國家。她另解釋因民進黨委員席次較少，策略上希望兩案能並陳。

來源：[傅崐萁「中國」改「大陸」禁用「我國」　吳釗燮：讓人民不可置信](https://www.ftvnews.com.tw/news/detail/2024502P01M1)

電視新聞文字稿明確標示說話者；未逐句核聽

為對傅及國民黨改用詞的政治批評，不當作法律上叛國、受指揮或實際放棄國籍的認定。；新聞稿說話者歸屬明確，但片中原聲／秒數本輪未核。；同篇王美惠、賴士葆、吳釗燮及傅崐萁的引文不能混入蘇語料。

[[案例/su-fu-china-mainland-wording-20240501-02|回到事件]]
