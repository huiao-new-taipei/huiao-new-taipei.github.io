---
id: "su-mainland-retort-20211013"
eventId: "su-zheng-su-20211013"
caseId: "su-zheng-su-20211013"
speaker: "蘇巧慧"
date: "2021-10-13"
datePrecision: "report-date-upper-bound"
medium: "written"
quizEligible: true
audioVerified: false
---

# 護父親時對國民黨的反擊

> 想要對中共卑躬屈膝，請去對岸

蘇貞昌與鄭麗文質詢衝突後，她在臉書回應要求父親道歉的聲音。

來源：[力挺院長老爸！蘇巧慧怒嗆國民黨：想對中共卑躬屈膝請去對岸](https://finance.ftvnews.com.tw/news/detail/2021A13W0175)

媒體引述本人臉書文字，未取得原貼永久連結

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/su-zheng-su-20211013|回到事件]]
