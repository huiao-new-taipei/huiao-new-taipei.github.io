---
id: "su-empty-talk-20230517"
eventId: "su-hou-announcement-20230517"
caseId: "su-hou-announcement-20230517"
speaker: "蘇巧慧"
date: "2023-05-17"
datePrecision: "report-date-upper-bound"
medium: "written"
quizEligible: true
audioVerified: false
---

# 評論侯友宜參選宣言

> 講了一堆廢話和空話

侯友宜獲國民黨徵召參選總統當日，蘇在臉書評論他的參選宣言。

來源：[侯友宜宣布參選「講一堆廢話」 戴瑋姍：令人擔憂要把台灣帶去哪？](https://dev.taisounds.news/news/content/71/60647)

同日新聞歸屬於本人臉書文字；與同篇戴瑋姍發言分開

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/su-hou-announcement-20230517|回到事件]]
