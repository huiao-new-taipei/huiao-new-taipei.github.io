---
id: "su-colleague-troublesome-20250101"
eventId: "su-procurement-response-20250102"
caseId: "wang-family-procurement-20250102"
speaker: "蘇巧慧"
date: "2025-01-01"
datePrecision: "report-date-upper-bound"
medium: "reported"
quizEligible: false
audioVerified: false
---

# 回應同事的問政品質

> 有這種問政品質的同事，令人困擾

同一新聞歸屬她對王鴻薇記者會標題與問政品質的回應；她否認參與採購行政流程。

來源：[又被王鴻薇指「大翻車」 蘇巧慧反擊：被打臉還不痛定思痛](https://www.nownews.com/news/6627309)

新聞以蘇巧慧回應／強調歸屬措辭，未取得本人聲明原件或核聽

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/wang-family-procurement-20250102|回到事件]]
