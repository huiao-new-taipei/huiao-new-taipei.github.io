---
id: "su-zhang-family-scrutiny-20220922-candidate-v7"
eventId: "su-hotnews152-zhang-20220922"
caseId: "zhang-shujuan-2022-2026"
speaker: "蘇巧慧"
date: "2022-09-22"
datePrecision: "day-secondary-program-date-not-audio-verified"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 節目接話：家族都會被檢驗

> 所有的家族確實都會被拿出來檢驗

2026聯合報引述韋淳祐還原的2022節目錄音：周玉蔻公布張淑娟姓名後問蘇聽後是否生氣，蘇以家族面對檢驗及事情發生後如何處理作答。本輪未取得完整原段，不能排除回答中另有自我舉例，也不能把主持人所作不實性緋聞指控當成蘇本人逐字指控。

來源：[蘇巧慧稱未談論他人私事 韋淳祐批文字遊戲：她接了話還給建議](https://udn.com/news/story/124652/9791759)

媒體引述具名批評者還原的舊錄音；完整原音待核

原話文字來自報導引述的錄音，不稱本輪已核原聲。；不能把她在場或接話等同本人說出張淑娟為緋聞女主角的特定不實指控。；『完全是在講自己』是她2026回應；原問題脈絡與她的解釋應並列，不先替讀者下說謊結論。

[[案例/zhang-shujuan-2022-2026|回到事件]]
