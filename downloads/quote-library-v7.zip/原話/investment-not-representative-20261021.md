---
id: "investment-not-representative-20261021"
eventId: "su-investment-interview-20261021"
caseId: "quantum-investment-grant-2022-2026"
speaker: "蘇巧慧"
date: "2026-10-21"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 以非公司負責人回應質疑

> 我妹妹不是這間公司的負責人

當天審計長答詢後，本人受訪稱部會已說明且文件依規定填具。這句的『負責人』須區分登記代表人與公司法第8條董事責任範圍；不能因登記代表人另有其人就不問她擔任董事的責任。

來源：[審計部要查曠世智能 蘇巧慧：合法的事情不怕查](https://udn.com/news/story/124652/9829362)

本人受訪報導

官方登記入口本輪403；歷史董事/營運長完整任期仍未取得原件。；多家新聞把營運長COO誤寫或混寫CEO；本檔不用CEO作確證職稱。；此句存在可追問的法律用詞差異，仍不能單憑這點宣告投資違法或說話者故意犯罪。

[[案例/quantum-investment-grant-2022-2026|回到事件]]
