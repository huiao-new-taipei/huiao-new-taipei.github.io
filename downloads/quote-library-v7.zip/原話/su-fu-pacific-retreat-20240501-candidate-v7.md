---
id: "su-fu-pacific-retreat-20240501-candidate-v7"
eventId: "su-fu-china-mainland-wording-20240501-02"
caseId: "su-fu-china-mainland-wording-20240501-02"
speaker: "蘇巧慧"
date: "2024-05-01"
datePrecision: "day-contemporary-report-of-same-day-facebook-post"
medium: "written"
quizEligible: true
audioVerified: false
---

# 書面反問：退到太平洋嗎

> 是要從花蓮一路退到太平洋了嗎？

太報當天引述她會後臉書貼文：她對照國民黨2020年的提案仍寫我國與中共，挖苦現在的改字要求；此問句是以地理退讓作比喻。與次日受訪同屬一個改用詞爭議，不能灌成兩個獨立政治事件。

來源：[傅崐萁要民進黨提案「中國」改「大陸」　蘇巧慧嗆：要不要改名「大陸國民黨」](https://www.taisounds.com/news/content/71/123071)

同時期媒體引述本人臉書貼文；原貼日依本題標示

書面政治挖苦，不是宣稱真有軍事撤退。；同日多篇媒體可能來自同一貼文，不等於取得原貼或多段原聲。；維持與傅的回應並列，不把她或對方的法律主張寫成法院認定。

[[案例/su-fu-china-mainland-wording-20240501-02|回到事件]]
