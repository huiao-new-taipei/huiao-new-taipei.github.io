---
id: "su-procurement-retort-20250102-v6"
eventId: "su-procurement-response-20250102"
caseId: "wang-family-procurement-20250102"
speaker: "蘇巧慧"
date: "2025-01-02"
datePrecision: "day-contemporaneous-news"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 回應採購質疑的反擊措辭

> 可恥又可悲

她在2025年1月2日回應王鴻薇對原文會採購及其夫婿擔任評審的質疑，批評對方未舉證她違法，仍利用她的名字吸引媒體關注；另稱夫婿只參與專業評審、沒有行政作業。此題只辨認本人反擊的用語；採購疑點及否認是否成立，須另看原始文件。

來源：[原文](https://newtalk.tw/news/view/2025-01-02/951387)

同日媒體直接引述；蘇巧慧辦公室提供的影片出版頁可定位，未逐句核聽。

不能把王鴻薇在同一新聞中的批評冒充蘇巧慧原話。這句反擊本身不證明採購違法，也不證明所有質疑均不實。『她先生評分第一的廠商首輪淘汰』不得轉述成她先生被淘汰。

[[案例/wang-family-procurement-20250102|回到事件]]
