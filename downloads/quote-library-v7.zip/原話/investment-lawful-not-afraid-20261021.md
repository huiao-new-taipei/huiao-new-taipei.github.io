---
id: "investment-lawful-not-afraid-20261021"
eventId: "su-investment-interview-20261021"
caseId: "quantum-investment-grant-2022-2026"
speaker: "蘇巧慧"
date: "2026-10-21"
datePrecision: "day-as-reported"
medium: "spoken"
quizEligible: false
audioVerified: false
---

# 回應審計部將調查

> 合法的事情不怕查

蘇在新北工業會活動受訪說明妹妹任職與投資爭議，並批對手在其民調領先時炒作舊案。與上筆屬同一次日期/議題的回應，非第二個查核結果。

來源：[藍委控胞妹獲投資案 蘇巧慧：對手不要我民調領先就炒作舊案](https://news.tvbs.com.tw/politics/4039408)

本人受訪報導

當事人合法宣稱不等於審計結論；承諾半個月初步結果仍未到期。；截至本次查找未定位到針對本案已公開完成的審計報告或司法裁決，不把未找到當成不存在/清白證明。

[[案例/quantum-investment-grant-2022-2026|回到事件]]
