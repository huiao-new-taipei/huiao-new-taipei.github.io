---
id: "investment-office-double-standard-20261014"
eventId: "su-office-investment-20261014"
caseId: "quantum-investment-grant-2022-2026"
speaker: "劉芳宇（蘇巧慧競選辦公室發言人）"
date: "2026-10-14"
datePrecision: "day-as-reported"
medium: "reported"
quizEligible: false
audioVerified: false
---

# 競辦以雙重標準反擊

> 根本是雙重標準、選舉抹黑。

劉芳宇把曠世股權投資與盧秀芳公司台中市府標案作比較，稱妹妹非公司負責人。是競辦回應，不是蘇本人原話；兩邊交易類型不同，不能只靠比較就結案。

來源：[藍質疑妹妹涉特權投資 蘇巧慧競辦：根本是雙標選舉抹黑](https://www.cna.com.tw/news/aipl/202610140106.aspx)

競辦發言人聲明與國民黨團指控報導

未取得原始競辦書面稿；不可標成蘇本人現場說話。；此輪未查盧秀芳個案，不以競辦對第三人的主張作已證事實。；股權投資、SIIR補助及別案政府採購要分開核適用法規。

[[案例/quantum-investment-grant-2022-2026|回到事件]]
