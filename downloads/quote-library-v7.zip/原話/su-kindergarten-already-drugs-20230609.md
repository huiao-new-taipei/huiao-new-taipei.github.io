---
id: "su-kindergarten-already-drugs-20230609"
eventId: "su-kindergarten-20230609-presser"
caseId: "kindergarten-2023-2026"
speaker: "蘇巧慧"
date: "2023-06-09"
datePrecision: "day"
medium: "spoken"
quizEligible: true
audioVerified: false
---

# 記者會再用「餵食毒品」

> 這都已經是餵食毒品的狀況

民進黨立院黨團就幼兒園案開記者會，她反駁法規不清與家長未有共識的說法，將案件描述為已餵食毒品。

來源：[孩子中毒不重要？民進黨批侯友宜只顧選舉拉票：新北幼兒園餵毒案，宛如恩恩案翻版](https://watchout.tw/reports/v0s8YDGsKcXzg38Bv68s)

記者廖昱涵當日現場採訪及攝影報導

需與檢方之後結果並列，不能當實際餵毒認定。；未取得該場完整原片，不能提供秒數或自製假口播影片。

[[案例/kindergarten-2023-2026|回到事件]]
