---
id: "su-drag-under-20211013"
eventId: "su-zheng-su-20211013"
caseId: "su-zheng-su-20211013"
speaker: "蘇巧慧"
date: "2021-10-13"
datePrecision: "report-date-upper-bound"
medium: "written"
quizEligible: true
audioVerified: false
---

# 同一貼文的後半句

> 拜託不要連其他臺灣人也一起拖下水

接在「請去對岸」之後，屬同一貼文與同一事件。

來源：[力挺院長老爸！蘇巧慧怒嗆國民黨：想對中共卑躬屈膝請去對岸](https://finance.ftvnews.com.tw/news/detail/2021A13W0175)

媒體引述本人臉書文字，未取得原貼永久連結

本句只能支持她使用過這種措辭；不單獨證明對手違法、她的隱藏動機，或全部日常言論的分布。原文若屬反問或比喻，保留其語氣及政策語境。

[[案例/su-zheng-su-20211013|回到事件]]
