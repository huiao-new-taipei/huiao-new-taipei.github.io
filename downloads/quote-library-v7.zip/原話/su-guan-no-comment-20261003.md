---
id: "su-guan-no-comment-20261003"
eventId: "su-guan-response-20261003"
caseId: "guan-min-2018-2026"
speaker: "蘇巧慧"
date: "2026-10-03"
datePrecision: "day"
medium: "reported"
quizEligible: false
audioVerified: false
---

# 回應管中閔案：我沒有評論

> 我沒有評論

第七屆瘋北大兒童上街趣活動聯訪回應管中閔批評；其否認範圍是當年個人論文評論，並主張當時談校長遴選制度。不能省掉此範圍變成從未評論任何事。

來源：[管中閔控論文案「幫凶」　蘇巧慧：只針對大學校長遴選制度](https://ctinews.com/news/items/zMW5mBqwWN)

本人當日聯訪媒體直接短引文；自由時報報導可交叉核背景

目前當日CNA把具體抄襲比對歸張廖萬堅，蘇主要談制度，不能只憑共同出席就證明本句必為謊言。；共同出席與政治責任仍可追問，但需另外證據。

[[案例/guan-min-2018-2026|回到事件]]
