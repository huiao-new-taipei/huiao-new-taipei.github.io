---
id: "food-office-same-stage-20260715"
eventId: "su-office-food-stage-20260715"
caseId: "food-oil-2026"
speaker: "吳思萱（蘇巧慧競選辦公室發言人）"
date: "2026-07-15"
datePrecision: "day-as-reported"
medium: "reported"
quizEligible: false
audioVerified: false
---

# 競辦回應與洪堯昆同台

> 如此行為實在不厚道。

吳思萱回應7/3同台爭議，稱蘇出席寵物食品及用品公會辦的寵物展，台上貴賓由主辦方邀請，且李四川也出席。這是競辦發言人，不能放成『蘇巧慧說』。

來源：[同台毒油關鍵人！李四川辦批蘇巧慧「裝沒事」 蘇營反擊：你也在](https://news.tvbs.com.tw/politics/3257812)

雙方競辦回應報導

尚未取得競辦原始書面稿或發言人完整錄影。；同台/合照不證明私下關係、護航、關說或違法；對手是否同場亦不能回答食安監督是否充足。

[[案例/food-oil-2026|回到事件]]
