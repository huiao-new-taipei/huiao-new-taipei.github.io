---
id: "source-e72667aa1e9ff13c"
source_url: "https://ivod.ly.gov.tw/Demand/Speech/153103"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 立法院 iVOD 153103：全文與影片

[開啟原始來源](https://ivod.ly.gov.tw/Demand/Speech/153103)

來源類型：官方逐字稿與影片。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/children-colleagues-20240528|批評法案，為何要孩子面對同學？]]
