---
id: "source-c9a950becdff4dda"
source_url: "https://news.tvbs.com.tw/politics/4030454"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 當年錄音的報導與批評

[開啟原始來源](https://news.tvbs.com.tw/politics/4030454)

來源類型：媒體引述錄音，未獨立核音。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/zhang-shujuan-2022-2026|張淑娟受了傷，誰來面對？]]
