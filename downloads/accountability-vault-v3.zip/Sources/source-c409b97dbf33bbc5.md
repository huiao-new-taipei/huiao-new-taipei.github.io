---
id: "source-c409b97dbf33bbc5"
source_url: "https://www.judicial.gov.tw/tw/cp-1888-1206232-5bd2b-1.html"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 北院 2024 年一審新聞稿

[開啟原始來源](https://www.judicial.gov.tw/tw/cp-1888-1206232-5bd2b-1.html)

來源類型：官方司法文件。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/zhang-shujuan-2022-2026|張淑娟受了傷，誰來面對？]]
