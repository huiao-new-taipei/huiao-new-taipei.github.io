---
id: "source-fd452c6a39d6878a"
source_url: "https://www.fountmedia.io/article/162756"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 原節目出版頁

[開啟原始來源](https://www.fountmedia.io/article/162756)

來源類型：節目出版者。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/zhang-shujuan-2022-2026|張淑娟受了傷，誰來面對？]]
