---
id: "source-39e55fcab85003b4"
source_url: "https://www.cna.com.tw/news/aipl/202610050103.aspx"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 競辦回應

[開啟原始來源](https://www.cna.com.tw/news/aipl/202610050103.aspx)

來源類型：競辦回應。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/guan-min-2018-2026|管中閔重提往事：共同記者會之後呢？]]
- [[Cases/kindergarten-2023-2026|從疑似餵藥到二度不起訴，她如何交代？]]
