---
id: "source-81a03510ee2cac2d"
source_url: "https://www.cna.com.tw/news/aipl/202605260258.aspx"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 中央社：投資及補助爭議

[開啟原始來源](https://www.cna.com.tw/news/aipl/202605260258.aspx)

來源類型：指控與機關回應。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/quantum-investment-grant-2022-2026|曠世智能的近兩千萬投資，揭露了哪些關係？]]
