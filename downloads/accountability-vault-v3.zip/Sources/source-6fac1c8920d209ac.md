---
id: "source-6fac1c8920d209ac"
source_url: "https://www.cna.com.tw/news/asoc/202609070246.aspx"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 中央社：告發與經部回應

[開啟原始來源](https://www.cna.com.tw/news/asoc/202609070246.aspx)

來源類型：告發行動及回應報導。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/quantum-investment-grant-2022-2026|曠世智能的近兩千萬投資，揭露了哪些關係？]]
