---
id: "source-11e36107f085beeb"
source_url: "https://www.tpp.org.tw/newsdetail/4830"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 民眾黨：2026 年 9 月告發聲明

[開啟原始來源](https://www.tpp.org.tw/newsdetail/4830)

來源類型：指控方原始聲明。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/quantum-investment-grant-2022-2026|曠世智能的近兩千萬投資，揭露了哪些關係？]]
