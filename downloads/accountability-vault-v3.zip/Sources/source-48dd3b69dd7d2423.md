---
id: "source-48dd3b69dd7d2423"
source_url: "https://video.udn.com/news/1324213"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 聯合影音：民眾黨記者會

[開啟原始來源](https://video.udn.com/news/1324213)

來源類型：指控方記者會報導。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/weiru-akaswap-grants-2024-2026|威如與 akaSwap 的關係，不能只靠雙方口號。]]
