---
id: "source-655dd97cc15954fe"
source_url: "https://www.cna.com.tw/news/aipl/202210310143.aspx"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 中央社：桃園總圖質疑與政院說明

[開啟原始來源](https://www.cna.com.tw/news/aipl/202210310143.aspx)

來源類型：指控與機關回應。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/taoyuan-library-subcontract-2022|承諾不投政府標案，之後的分包算不算？]]
