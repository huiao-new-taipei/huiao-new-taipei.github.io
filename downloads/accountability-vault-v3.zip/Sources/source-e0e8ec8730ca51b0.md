---
id: "source-e0e8ec8730ca51b0"
source_url: "https://taipeipost.org/84013/"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 台北郵報：分包及會議指控

[開啟原始來源](https://taipeipost.org/84013/)

來源類型：記者會報導。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/taoyuan-library-subcontract-2022|承諾不投政府標案，之後的分包算不算？]]
