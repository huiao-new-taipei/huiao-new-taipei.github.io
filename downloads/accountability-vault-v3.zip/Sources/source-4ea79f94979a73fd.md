---
id: "source-4ea79f94979a73fd"
source_url: "https://www.pcc.moj.gov.tw/media/325865/112-07-12-%E6%96%B0%E5%8C%97%E5%9C%B0%E6%AA%A2%E7%BD%B2%E5%81%B5%E8%BE%A6%E6%B6%89%E5%AB%8C%E9%A4%B5%E9%A3%9F%E5%B9%BC%E7%AB%A5%E4%B8%8D%E6%98%8E%E8%97%A5%E7%89%A9%E6%A1%88-%E5%81%B5%E6%9F%A5%E7%B5%82%E7%B5%90%E7%82%BA%E4%B8%8D%E8%B5%B7%E8%A8%B4%E8%99%95%E5%88%86-%E6%96%B0%E8%81%9E%E7%A8%BF-%E6%A0%B8%E5%AE%9A-docx.pdf?mediaDL=true"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 新北地檢署 2023-07-12 原始新聞稿

[開啟原始來源](https://www.pcc.moj.gov.tw/media/325865/112-07-12-%E6%96%B0%E5%8C%97%E5%9C%B0%E6%AA%A2%E7%BD%B2%E5%81%B5%E8%BE%A6%E6%B6%89%E5%AB%8C%E9%A4%B5%E9%A3%9F%E5%B9%BC%E7%AB%A5%E4%B8%8D%E6%98%8E%E8%97%A5%E7%89%A9%E6%A1%88-%E5%81%B5%E6%9F%A5%E7%B5%82%E7%B5%90%E7%82%BA%E4%B8%8D%E8%B5%B7%E8%A8%B4%E8%99%95%E5%88%86-%E6%96%B0%E8%81%9E%E7%A8%BF-%E6%A0%B8%E5%AE%9A-docx.pdf?mediaDL=true)

來源類型：檢方原始文件。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/kindergarten-2023-2026|從疑似餵藥到二度不起訴，她如何交代？]]
