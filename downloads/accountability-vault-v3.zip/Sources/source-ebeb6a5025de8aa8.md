---
id: "source-ebeb6a5025de8aa8"
source_url: "https://ori.ntu.edu.tw/news/download/fileSn/2"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 台大正式會議紀錄

[開啟原始來源](https://ori.ntu.edu.tw/news/download/fileSn/2)

來源類型：校方原始文件。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/guan-min-2018-2026|管中閔重提往事：共同記者會之後呢？]]
