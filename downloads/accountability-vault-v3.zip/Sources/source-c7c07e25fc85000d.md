---
id: "source-c7c07e25fc85000d"
source_url: "https://news.pts.org.tw/article/487345"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 公視：較早政治獻金支出報導

[開啟原始來源](https://news.pts.org.tw/article/487345)

來源類型：當事人聲明報導、當年採訪報導。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/campaign-design-expense-2020-2023|約 586 萬元文宣活動支出，交給妹妹公司。]]
- [[Cases/taoyuan-library-subcontract-2022|承諾不投政府標案，之後的分包算不算？]]
