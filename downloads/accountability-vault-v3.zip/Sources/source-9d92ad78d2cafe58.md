---
id: "source-9d92ad78d2cafe58"
source_url: "https://www.youtube.com/watch?v=INtBWXWwNRs"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 民視新聞影片

[開啟原始來源](https://www.youtube.com/watch?v=INtBWXWwNRs)

來源類型：新聞影片入口。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/wang-family-procurement-20250102|回應採購質疑，用上「可恥又可悲」。]]
