---
id: "source-3bc81d60d9fd5250"
source_url: "https://www.taisounds.com/news/content/0/44807"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 太報：羅智強質疑與本人貼文回應

[開啟原始來源](https://www.taisounds.com/news/content/0/44807)

來源類型：當年報導及貼文截圖。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/campaign-design-expense-2020-2023|約 586 萬元文宣活動支出，交給妹妹公司。]]
