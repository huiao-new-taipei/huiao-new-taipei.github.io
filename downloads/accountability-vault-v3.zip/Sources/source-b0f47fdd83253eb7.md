---
id: "source-b0f47fdd83253eb7"
source_url: "https://www.ftvnews.com.tw/news/detail/2025102P05M1"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 民視：本人反擊與程序說明

[開啟原始來源](https://www.ftvnews.com.tw/news/detail/2025102P05M1)

來源類型：同時期直接引述。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/wang-family-procurement-20250102|回應採購質疑，用上「可恥又可悲」。]]
