---
id: "source-8bc005ff63d5a8ff"
source_url: "https://udn.com/news/story/124652/9823942"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 舊貼文截圖與競辦批評

[開啟原始來源](https://udn.com/news/story/124652/9823942)

來源類型：媒體報導對手公布截圖。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/kindergarten-2023-2026|從疑似餵藥到二度不起訴，她如何交代？]]
