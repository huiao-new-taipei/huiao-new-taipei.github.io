---
id: "source-08baf6dd890ef7c9"
source_url: "https://www.taisounds.com/news/content/71/259023"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 太報：國發基金六點說明

[開啟原始來源](https://www.taisounds.com/news/content/71/259023)

來源類型：機關聲明媒體刊載。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/quantum-investment-grant-2022-2026|曠世智能的近兩千萬投資，揭露了哪些關係？]]
