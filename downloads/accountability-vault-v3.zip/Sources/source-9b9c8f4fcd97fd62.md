---
id: "source-9b9c8f4fcd97fd62"
source_url: "https://www.nownews.com/news/6627309"
source_date: "未逐筆確認，依原頁日期及所連案例閱讀"
---

# 前一日書面回應

[開啟原始來源](https://www.nownews.com/news/6627309)

來源類型：本人回應報導。

本筆是來源入口及反向連結，沒有鏡像全文。出版日期未逐筆獨立確認，不把收錄日當作出版日。

## 使用本來源的案例

- [[Cases/wang-family-procurement-20250102|回應採購質疑，用上「可恥又可悲」。]]
